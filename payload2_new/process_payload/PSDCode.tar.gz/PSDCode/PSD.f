C=======================================================================
C     START OF POROSITY ROUTINE

C     Consists of two routines,
C     -  porosity volume sampling (porosity)
C     -  largest sphere point sampling (pore size distribution PSD)
C
C     Based on spherical approximation algorithms outlined by
C     K. T. Thomson, K. E. Gubbins, Langmuir 16, 5761 (2000).
C
C     *  Network atoms A probed by adsorbate particle Z
C     *  Closest approach of Z to A requires interaction distances
C        sigmaAA, sigmaAZ and sigmaZZ
C     *  Diatomic Nitrogen adsorbate in porous carbon for example,
C        sigmaAA = 3.4A(C-C), sigmaAZ = 3.36A(C-N2) sigmaZZ=3.75A(N2-N2)
C
C     *  Porosity requires use of 're-entrant' surface definition
C        using a minimum approach of (sigmaAZ-0.5*sigmaZZ)
C
C
C     FIX Generalize to more than single component!
C
C     - Absorbate insertions of particle Z can not be closer than
C       sigmaAZ to any network atom A (center to center distance).
C     - Pore sizes need a (sigmaAZ-0.5*sigmaZZ) deduction to ensure
C       they do not overlap network atoms.
C
C
C     Define probe distance
C     ---------------------
C     Test particle is a Lennard-Jones sphere of diameter sigmaZZ while
C     network atoms are spheres of diameter sigmaAZ-0.5*sigmaZZ where,
C     sigmaAZ = LJ solid-fluid interaction parameter
C     sigmaAA = LJ solid-solid interaction parameter
C     sigmaZZ = LJ fluid-fluid interaction parameter
C
C     Ensure atom xyz position are positive
C
C
C     Timings (1237 atoms a-C network, 10000 points,3 attempt,100 moves)
C     * No NN routine -172 sec
C     * po_res=5   - 79 sec
C     * po_res=10  - 20 sec
C     * po_res=20  - 7 sec
C     * po_res=40  - 3 sec





      program POROSITY
      
      implicit none

      integer x_res, y_res, z_res, dump_integer
      integer i, j, k, l, m, n, l2, m2, n2, binpoint
      integer point_reject, move_reject
      integer por_sample,por_reject,por_acount
      integer res_sub, por_count, psdbin(1000000)
      integer por_move, por_attempt
      real ran2, disx, disy, disz, dis2x, dis2y, dis2z
      real xc,yc,zc,rr, por_res
      real por_porosity
      real tempmin, tempmax, por_locr(100,100,100),por_glor(100,100,100)
      real point_xf(1000000), point_yf(1000000), point_zf(1000000)
      real point_xi(1000000), point_yi(1000000), point_zi(1000000)
      real por_max, u_psd(1000000)
      real sigmaAA, sigmaAZ, sigmaZZ, sigma_adjust
      real dis_reentr
      real point_x, point_y, point_z, por1_max, por2_max, por3_max
      real por_maximum
      real point1_x, point1_y, point1_z
      real point2_x, point2_y, point2_z
      real cell_vcm, por_vcm, cell_mgr, por_spec

      integer atom_max,pbc_option,max_points,iseed,count,loop
      integer po_cell(40,40,40), po_cellC(40,40,40,1000)
      integer xindex, yindex, zindex, po_res
      real x(1000000),y(1000000),z(1000000)
      real xl,yl,zl,xl2,yl2,zl2,xl2inv,yl2inv,zl2inv
      real max_walk, po_lcellx, po_lcelly, po_lcellz
      real bin_res, temp_x, temp_y, temp_z, grid_dist
      real por1_min, atomic_w

      character label*2






      print*,' '
      print*,'-- POROSITY, SURFACE, PSD'

C     ======================
C     Pore Size Distribution
C     ======================

      open(9,file='PSD.inp',status='old')
!     open(10,file='initial.xyz',status='unknown')
!     open(10,file='hrmc01.xyz',status='unknown')
      open(10,file='xyz_final.xyz',status='unknown')
      open(11,file='psd.dat',status='unknown')
!      open(53,file='R_poreF.xyz',status='unknown')
!      open(54,file='R_poreI.xyz',status='unknown')
      
C     Read in PSD.inp file
C     --------------------
      read(9,*) atom_max
      read(9,*) xl
      read(9,*) yl
      read(9,*) zl
      read(9,*) pbc_option
      read(9,*) bin_res
      read(9,*) max_points
      read(9,*) por_sample
      read(9,*) por_attempt
      read(9,*) por_move
      read(9,*) max_walk
      read(9,*) sigmaAZ
      read(9,*) sigmaZZ
      read(9,*) atomic_w
      read(9,*) po_res
      read(9,*) iseed


C     Some checks
C     -----------
      if(po_res.gt.40) then
        print*,'ERROR - po_res too high'
        stop
      end if



C     Read in initial.xyz file
C     ------------------------
      read(10,'(i6,/)') dump_integer
      do i=1, atom_max
        read(10,*) label,x(i),y(i),z(i)
!         read(10,*) x(i),y(i),z(i)
      end do

      
      xl2 = 0.5 * xl
      yl2 = 0.5 * yl
      zl2 = 0.5 * zl
      xl2inv = 1.0 / xl2
      yl2inv = 1.0 / yl2
      zl2inv = 1.0 / zl2
      
C     -- parameter to increase or decrease re-entrant surface distance
      sigma_adjust = 0.0

C     -- Re-entrant molecular surface definition
      dis_reentr    =  (sigmaAZ - 0.5*sigmaZZ)+sigma_adjust
      
C     -- Zero arrays
      por_count = 0
      por_acount = 0
      do i=1, max_points
        psdbin(i)= 0
      end do
      do i=1, po_res
        do j=1, po_res
          do k=1, po_res
          
            po_cell(i,j,k) = 0
          
          end do
        end do
      end do
      
      
C     Make neighbor list for grid
      po_lcellx = xl/po_res
      po_lcelly = yl/po_res
      po_lcellz = zl/po_res
      
      
      grid_dist = sqrt(po_lcellx*po_lcellx+po_lcelly*po_lcelly+
     :            po_lcellz*po_lcellz)
     
     
      print*,'-- CALCULATE NN GRID ARRAYS Start'

      
      do i=1, po_res
        do j=1, po_res
          do k=1, po_res
          
            temp_x = (i*po_lcellx) - 0.5*po_lcellx
            temp_y = (j*po_lcelly) - 0.5*po_lcelly
            temp_z = (k*po_lcellz) - 0.5*po_lcellz
            
C     -- work out closest atom distance
            por1_min = 10000.0
            do l=1, atom_max
              xc = x(l) - temp_x
              yc = y(l) - temp_y
              zc = z(l) - temp_z

              if(pbc_option.eq.1) then
	        xc = xc -(int(xc*xl2inv)*xl)
                yc = yc -(int(yc*yl2inv)*yl)
                zc = zc -(int(zc*zl2inv)*zl)
              else if(pbc_option.eq.3) then
                xc = xc -(int(xc*xl2inv)*xl)
                yc = yc -(int(yc*yl2inv)*yl)
              else
                continue
 	      endif

              rr = sqrt(xc*xc+yc*yc+zc*zc)

              if(rr.lt.por1_min) por1_min = rr
            end do
            
            count = 0
            do l=1, atom_max
              xc = x(l) - temp_x
              yc = y(l) - temp_y
              zc = z(l) - temp_z

              if(pbc_option.eq.1) then
	        xc = xc -(int(xc*xl2inv)*xl)
                yc = yc -(int(yc*yl2inv)*yl)
                zc = zc -(int(zc*zl2inv)*zl)
              else if(pbc_option.eq.3) then
                xc = xc -(int(xc*xl2inv)*xl)
                yc = yc -(int(yc*yl2inv)*yl)
              else
                continue
 	      endif

              rr = sqrt(xc*xc+yc*yc+zc*zc)
              
              if(rr.lt.(por1_min + grid_dist)) then
                count = count + 1
                po_cell(i,j,k) = po_cell(i,j,k) + 1
                po_cellC(i,j,k,po_cell(i,j,k)) = l
              
              end if
            
            end do
            
            if(count.eq.1000) then
              print*,'ERROR - po_res too low...to many neighbors'
              stop
            end if
            
            
          end do
        end do
      end do
      
      print*,'-- CALCULATE NN GRID ARRAYS Finish'
      

      
C     SAMPLING MAIN LOOP
C     ------------------

      do i=1, por_sample

        if(por_sample.gt.1) then
          if(mod(i,100).eq.0) then
            print*,'PSD Sampling:',i
          end if
        end if

        por_maximum = 0.0

C     -- Pick random point
        point_x = RAN2(iseed) * xl
        point_y = RAN2(iseed) * yl
        point_z = RAN2(iseed) * zl
        



C     -- Find closest atom to initial point
        point_reject = 0
        por1_max = 10000

        do j=1, atom_max
          xc = x(j) - point_x
          yc = y(j) - point_y
          zc = z(j) - point_z

          if(pbc_option.eq.1) then
	    xc = xc -(int(xc*xl2inv)*xl)
            yc = yc -(int(yc*yl2inv)*yl)
            zc = zc -(int(zc*zl2inv)*zl)
          else if(pbc_option.eq.3) then
            xc = xc -(int(xc*xl2inv)*xl)
            yc = yc -(int(yc*yl2inv)*yl)
          else
            continue
 	  endif

          rr = sqrt(xc*xc+yc*yc+zc*zc)



C     -- If point too close to atom, reject
C        Sample point can't be inside bulk atom
          if(rr.le.dis_reentr) then
            point_reject = 1
            exit
          end if

          if(rr.gt.dis_reentr) then
            if((rr-dis_reentr).lt.por1_max) then
              point1_x = point_x
              point1_y = point_y
              point1_z = point_z

              por1_max = rr - dis_reentr

            end if
          end if

        end do


C     -- Random walk point
        if(point_reject.ne.1) then

          do l=1,por_attempt

            point_x = point1_x
            point_y = point1_y
            point_z = point1_z
            por2_max = por1_max



            do j=1, por_move

              move_reject = 0
              por3_max = 10000

C     -- Pick random point displacement
              disx = (0.5 - RAN2(iseed))*1.0
              disy = (0.5 - RAN2(iseed))*1.0
              disz = (0.5 - RAN2(iseed))*1.0

C     -- Ensure periodic boundaries
              if(pbc_option.eq.1) then

                point2_x = mod(point_x+disx+xl,xl)
                point2_y = mod(point_y+disy+yl,yl)
                point2_z = mod(point_z+disz+zl,zl)
              else if(pbc_option.eq.3) then
                point2_x = mod(point_x+disx+xl,xl)
                point2_y = mod(point_y+disy+yl,yl)
              else
                point2_x = point_x + disx
                point2_y = point_y + disy
                point2_z = point_z + disz
 	      endif
 	      
              xindex = (int(point2_x/po_lcellx))+1
              yindex = (int(point2_y/po_lcelly))+1
              zindex = (int(point2_z/po_lcellz))+1


C     -- Find closest atom (radius of pore)
C     -- FIX insert neighbor list here for speed

C             do k=1, atom_max
              
              do loop=1, po_cell(xindex,yindex,zindex)
              
                k = po_cellC(xindex,yindex,zindex,loop)

                xc = x(k) - point2_x
                yc = y(k) - point2_y
                zc = z(k) - point2_z

                if(pbc_option.eq.1) then
	          xc = xc -(int(xc*xl2inv)*xl)
                  yc = yc -(int(yc*yl2inv)*yl)
                  zc = zc -(int(zc*zl2inv)*zl)
                else if(pbc_option.eq.3) then
                  xc = xc -(int(xc*xl2inv)*xl)
                  yc = yc -(int(yc*yl2inv)*yl)
                else
                  continue
 	        endif

                rr = sqrt(xc*xc+yc*yc+zc*zc)

C     -- If point moves too close to atom, reject
                if(rr.le.dis_reentr) then
                  move_reject = 1
                  exit
                end if
C     -- Work out new maximum sphere size

                if(move_reject.eq.1) then
                  print*,'SCREW UP!!!'
                  stop
                end if

                if(rr-dis_reentr.lt.por3_max) then
                  por3_max = rr-dis_reentr
                end if


              end do
              

C     -- If sphere size is smaller than before, reject
              if(por3_max.le.por2_max) then
                move_reject = 1
              end if

C     -- Check that original point is within new sphere

              xc = point1_x - point2_x
              yc = point1_y - point2_y
              zc = point1_z - point2_z

              if(pbc_option.eq.1) then
	        xc = xc -(int(xc*xl2inv)*xl)
                yc = yc -(int(yc*yl2inv)*yl)
                zc = zc -(int(zc*zl2inv)*zl)
              else if(pbc_option.eq.3) then
                xc = xc -(int(xc*xl2inv)*xl)
                yc = yc -(int(yc*yl2inv)*yl)
              else
                continue
 	      endif

              rr = sqrt(xc*xc+yc*yc+zc*zc)

              if(rr.ge.por3_max) then
                move_reject = 1
              end if


C     -- If move increases radius without overlap, accept and update
              if(move_reject.eq.0) then
                point_x = point2_x
                point_y = point2_y
                point_z = point2_z
                por2_max = por3_max
              end if

            end do

            if(por2_max.gt.por_maximum) then
              por_maximum = por2_max

            end if


          end do
          

          
C     -- Porosity count
C        If point is not overlapping atoms and is within a sphere
C        sufficient to enclose adsorbate probe atoms, count the
C        point as accepted
          if(2.0*por_maximum.gt.sigmaZZ) then
            por_acount = por_acount + 1
C     -- Initial non-overlapping test point location
            point_xi(por_acount) = point1_x
            point_yi(por_acount) = point1_y
            point_zi(por_acount) = point1_z

C     -- Final position of point (max sphere origin containing initial
C        test point
            point_xf(por_acount) = point_x
            point_yf(por_acount) = point_y
            point_zf(por_acount) = point_z
            

C     -- Converting from radius to diameter for x-axis PSD output
            binpoint = int(2.0*por_maximum/bin_res)
            psdbin(binpoint) = psdbin(binpoint) + 1
            por_count = por_count + 1

          end if



        end if
      end do
      
      


C     Porosity, pore volume calculation
      if(por_acount.ne.0) then
        por_porosity = real(por_acount)/real(por_sample)
      else
        por_porosity = 0.0
      end if

C     -- Cell pore volume in cm^3
      cell_vcm = xl*yl*zl * 1e-24
      por_vcm = cell_vcm * por_porosity

C     -- Cell mass in grams
C     FIX - generalize to atomic weight input
      cell_mgr = atom_max * atomic_w / 6.0221415e+23

C     -- Total Specific Pore Volume (cm^3/g)
C     -- Used to scale normalized PSD
      por_spec = por_vcm/cell_mgr

      print*,'Porosity:', por_porosity,por_acount
      print*,'Total Specific Pore Volume (cm^3/g):', por_spec




      do i=1, 1000
C     -- 2.0 is for correct scaling of radius to diameter x-axis
C        conversion
        u_psd(i) = (real(psdbin(i))/real(por_count))
     :             *por_spec/bin_res
      end do
      print*,'Samples Accepted:',por_count

C     Write out point XYZ file
!      write(53,'(i6,/)') por_acount
!      do i=1, por_acount
!        write(53,'(a,2x,3(F11.6,2X))') 'AA',point_xf(i),point_yf(i),
!     :  point_zf(i)
!      end do

!      write(54,'(i6,/)') por_acount
!      do i=1, por_acount
!        write(54,'(a,2x,3(F11.6,2X))') 'BB',point_xi(i),point_yi(i),
!     :  point_zi(i)
!      end do
      
C     Write out PSD
C     -------------
      do i=1,max_points
        write(11,111)i*bin_res,u_psd(i)
  111   format(f8.4,f8.4)
      end do



!      close(53)
!      close(54)

      return
      end

C     END OF POROSITY ROUTINE
C=======================================================================



C=======================================================================
C     START OF RAN2 FUNCTION

      FUNCTION RAN2(idum)

      INTEGER idum,IM1,IM2,IMM1,IA1,IA2,IQ1,IQ2,IR1,IR2,NTAB,NDIV
      REAL ran2,AM,EPS,RNMX
      PARAMETER (IM1=2147483563,IM2=2147483399,AM=1./IM1,IMM1=IM1-1,
     * IA1=40014,IA2=40692,IQ1=53668,IQ2=52774,IR1=12211,
     * IR2=3791,NTAB=32,NDIV=1+IMM1/NTAB,EPS=1.2e-7,RNMX=1.-EPS)

C Long period (? 2 \Theta 10 18 ) random number
C generator of L'Ecuyer with Bays­Durham shuffle
C and added safeguards. Returns a uniform random
C deviate between 0.0 and 1.0 (exclusive
C of the endpoint values). Call with idum a negative
C integer to initialize; thereafter, do not
C alter idum between successive deviates in a sequence.
C RNMX should approximate the largest
C floating value that is less than 1.

      INTEGER idum2,j,k,iv(NTAB),iy
      SAVE iv,iy,idum2
      DATA idum2/123456789/, iv/NTAB*0/, iy/0/
      if (idum.le.0) then
        idum=max(-idum,1)
C  Be sure to prevent idum = 0.
        idum2=idum
        do j=NTAB+8,1,-1
C Load the shuffle table (after 8 warm­ups).
          k=idum/IQ1
          idum=IA1*(idum-k*IQ1)-k*IR1
          if (idum.lt.0) idum=idum+IM1
          if (j.le.NTAB) iv(j)=idum
        enddo
        iy=iv(1)
      endif
      k=idum/IQ1
C Start here when not initializing.
      idum=IA1*(idum-k*IQ1)-k*IR1
C Compute idum=mod(IA1*idum,IM1) without over­
C flows by Schrage's method.
      if (idum.lt.0) idum=idum+IM1
      k=idum2/IQ2
      idum2=IA2*(idum2-k*IQ2)-k*IR2
C Compute idum2=mod(IA2*idum2,IM2) likewise.
      if (idum2.lt.0) idum2=idum2+IM2
      j=1+iy/NDIV
C Will be in the range 1:NTAB.
      iy=iv(j)-idum2
C Here idum is shuffled, idum and idum2 are com­
C bined to generate output.
      iv(j)=idum
      if(iy.lt.1)iy=iy+IMM1
      ran2=min(AM*iy,RNMX)
C Because users don't expect endpoint values.
      return
      END


C     END OF RAN2 FUNCTION
C=======================================================================

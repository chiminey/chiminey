c      ============================================
c      Hybrid Reverse Monte Carlo V1.1 - 20/08/2010
c      ============================================
c
c      Contributions to this code:
c      Dr. George Opletal,
c      Dr. Brendan O'Malley
c      Dr. Tim Petersen
c
c      Simulations Group, Applied Physcs RMIT, Melbourne Australia.
c
c      This HRMC version allows:
c
c       * Fitting of both the s(q) and g(r)
c       * Coordination constraint
c       * Potentials - EDIP(carbon), EDIP(silicon), SWP & SWP(silicon)
c       * Porosity Arrays
c
c
c	This code requires the following files to run,
c
c	HRMC.f -> source code
c	rmcen.inp -> simulation input variables
c	rmcen.h   -> header file
c
c
c      Version notes:
c
c      V1.1 -
c      Fix to incorrect brackets in EDIP carbon potential routine,
c      namely the two body term should have the form,
c
c      energy_atom(i)=energy_atom(i) +C_aa*(C_bb/rij**4-bond)
c    :                     *exp(C_sigma/(rij-C_a12))
c
c      (line 1361 in V1.0 code, line 1380 in this version (V1.1)
c
c      and the updating energy term also needed a similar change,
c
c      energy_sum=energy_sum +C_aa*(C_bb/rij**4-bond)
c    :                     *exp(C_sigma/(rij-C_a12))
c
c      (line 3565 in V1.0 code, line 3582 in this version (V1.1)
c
c
c---------------------------------------------------------------------------


        include 'rmcen.h'

        call MAIN

	stop
	end



c---------------------------------------------------------------------------

	subroutine MAIN

        include 'rmcen.h'
	integer loop
	real tempK_change1, tempK_change2, tempK_change3
	real tempK_change4
	real stage_length1, stage_length2, stage_length3
	real stage_length4, stage_length1_t, stage_length2_t
	real stage_length3_t, stage_length4_t
	double precision tdrop1, tdrop2, tdrop3, tdrop4, temper



c	===============================
c       Input parameters for simulation
c       ===============================
	call INPUT

c	================
c	Simulation timer
c       ================
	call CLOCKER

c	===========================================================
c       Create starting configuration and calculate cell parameters
c       ===========================================================
	call CELLSTRT

c	=====================================================
c       Calculate constants and g(r) extension for simulation
c       =====================================================
	call CONSTANT


c	=============================
c       Set flag for stage in routine
c       =============================
	nstage = 1


c       =======================================
c       Calculate initial g(r) and coordination
c       =======================================
  	call INITGRCD


c	======================
c       calculate initial s(q)
c       ======================
	call INITLSQ


c       recalculate initial g(r) and coordination as configuration reset
c       ================================================================
    	call initgrcd

c       recalculate initial s(q)
c       ========================
	call initlsq



c       write intial text to file
c       =========================
c	call wrposn




c       Equilibriation Stage
c       ====================


	stage_length1 =(lengthstage)
        stage_length2 =(lengthstage1-lengthstage)
        stage_length3 =(lengthstage2-lengthstage1)
        stage_length4 =(1-lengthstage2)

	stage_length1_t = stage_length1
	stage_length2_t = stage_length1 + stage_length2
	stage_length3_t = stage_length1 + stage_length2 +
     :  stage_length3
        stage_length4_t = 1


	tempK_change1 = tempK1-tempK
	tempK_change2 = tempK2-tempK1
	tempK_change3 = tempK3-tempK2
	tempK_change4 = 0
c	Last stage has no temperature drop.

        tdrop1 = tempK_change1/(stage_length1*npre)
        tdrop2 = tempK_change2/(stage_length2*npre)
        tdrop3 = tempK_change3/(stage_length3*npre)
        tdrop4 = tempk_change4/(stage_length4*npre)

	if(tsmooth_option) then
	  temper = tempk
	end if



c       Do npre initial steps which are discarded to allow
c       the system to equilibriate. after npre moves the
c       difference between the experimental and calculated
c       s(q)'s will oscillate about some mean value.


	do nmcstep = 1, npre


c	STAGE NUMBER
c       ============

        if(nmcstep.lt.(npre*stage_length1_t)) then
	  stage_no = 1
	end if

	if(nmcstep.ge.(npre*stage_length1_t).and.nmcstep.lt.
     :    (stage_length2_t)*npre) then
	  stage_no = 2
	end if

	if(nmcstep.ge.(npre*stage_length2_t).and.nmcstep.lt.
     :    (stage_length3_t)*npre) then
	  stage_no = 3
	end if


	if(nmcstep.ge.(npre*stage_length3_t).and.nmcstep.le.
     :    (stage_length4_t)*npre) then
	  stage_no = 4
	end if




c	STAGE 1
          if(stage_no.eq.1) then
	    if(tsmooth_option) then
	        temper = temper + tdrop1
	        tempK = temper
	    end if
            wf_energy =  2/(0.0000862*tempK)
          endif

c     	STAGE 2
          if(stage_no.eq.2) then
            if(tsmooth_option) then
	      temper = temper + tdrop2
	      tempK1 = temper
	    end if
 	    wf_energy =  2/(0.0000862*tempK1)
          endif

c       STAGE 3
	  if(stage_no.eq.3) then
            if(tsmooth_option) then
	      temper = temper + tdrop3
	      tempK2 = temper
	    end if
            wf_energy =  2/(0.0000862*tempK2)
 	  endif

c       STAGE 4
	  if(stage_no.eq.4) then
            if(tsmooth_option) then
	      temper = temper + tdrop4
	      tempK3 = temper
	    end if
            wf_energy =  2/(0.0000862*tempK3)
 	  endif

        if(scrwrite.eq.1) then
	if(mod(nmcstep,10000).eq.0) then
	print*,'S,3f,T,E g(r)er:',nmcstep,fsp3,
     :   temper, old_energy_total/nmol, total_gr_error


c	  print*,'Sp3    :', fsp3
c	  print*,'Temp     :', temper
c	  print*,'E        :', old_energy_total/nmol
c	  print*,'gr er    :', total_gr_error
c	  print*,'      '
	end if
	end if

c	STAGE 4 must be equilibriated (data write stage)
c	This stage is the main RMC Run


	  call mcarlostp



c       write total error
c       =================
          if(mod(nmcstep,ierror).eq.0) then
            call total_error
          endif


        end do

	call endtxt




c       Main Run
c       ========
	nstage = 2
	grcounter = 0


c       Calculate initial g(r) and coordination
c       =======================================
	call initgrcd


c       Recalculate initial s(q)
c       ========================
	call initlsq


	numbacc = 0


	do nmcstep = 1,irun

	  call mcarlostp


	  if(mvaptflg.eq.-1) then
	    numbacc = numbacc + 1
	  endif


c	write total error
c	=================
          if(mod(nmcstep,ierror).eq.0) then
            call total_error
          endif

	end do


c	Post Simulation Calculations
c	============================

	call grwrite
        call wrposn
	call endtxt


c	calculate distribution of coordination numbers
c	==============================================
	call coordn_atoms
	call Clocker


	return
	end



c---------------------------------------------------------------------------
        subroutine input

c       --------------------------------------------------
c 	This routine opens the rmcen.inp file and reads in
c	the system variables required for a simulation.
c	Output files are opened for dynamic recording.
c       --------------------------------------------------

        include 'rmcen.h'


	character*24 date
	real pi, qexpt(1000)
	parameter (pi=3.141592653589793)

	real q,sq
	integer k, kk
	character *12 outfile,xyzfile,grstfile
	character *12 errfile
        character *12 enfile


c	--------------------------------------------------
c	Read in rmcen.inp simulation variables
c	(see documentation for variable meaning)
c	--------------------------------------------------

        open(10,file='rmcen.inp',status='old')

	read(10,*) numbfile
	read(10,*) scrwrite
	read(10,*) istart
        read(10,*) nmol
	read(10,*) rho
	read(10,*) xlcell

        read(10,*) npre
        read(10,*) irun
        read(10,*) ierror

        read(10,*) nqpts
        read(10,*) hdcore
        read(10,*) stpszinp
        read(10,*) iseed

        read(10,*) radcordn

	read(10,*) pore_option
	read(10,*) pore_points
	read(10,*) pore_remove

        read(10,*) nmol_remove
        read(10,*) po_res

	read(10,*) edip_type
	read(10,*) nnlist_option
	read(10,*) tsmooth_option

	read(10,*) sq_option
	read(10,*) sp_option
	read(10,*) en_option
	read(10,*) gr_option

	read(10,*) tempK
	read(10,*) lengthstage
	read(10,*) tempK1
	read(10,*) lengthstage1
	read(10,*) tempK2
	read(10,*) lengthstage2
	read(10,*) tempK3

	read(10,*) nptsgr_expt
	read(10,*) gr_error
        read(10,*) nptssq
	read(10,*) sqerror
	read(10,*) nqstart
	read(10,*) nqfinish
	read(10,*) delq

	read(10,*) nmcordn
	read(10,*) frcordn
        read(10,*) wfcordn


c	--------------------------------------------------
c	Open files containing experimental sq and gr data
c	--------------------------------------------------

	open(11,file ='sqexp.dat',status='old')
	open(66,file ='grexp.dat',status='old')


c       --------------------------------------------------
c       Open output files
c
c	- hrmc.out -> contains simulation details
c	- hrmc.xyz -> contains the final xyz config
c	- hrmcpor.xyz -> contains the porosity grid
c       --------------------------------------------------

	write(outfile,21) numbfile
  21    format('hrmc',i2.2,'.out')

	open(21,file=outfile,status='unknown')

	write(xyzfile,22) numbfile
  22    format('hrmc',i2.2,'.xyz')

	open(22,file=xyzfile,status='unknown')

        write(xyzfile,81) numbfile
  81    format('hrmcpr',i2.2,'.xyz')

	open(81,file=xyzfile,status='unknown')

	write(xyzfile,56) numbfile
  56    format('start',i2.2,'.xyz')

  	open(56,file=xyzfile,status='unknown')


c       --------------------------------------------------
c	Open Initial structure factor file
c
c	- sqinput.dat -> contains the initial sq with any
c	  truncations of the low q region (from input file)
c       --------------------------------------------------

	open(33, file = 'sqinput.dat', status = 'unknown')


c       --------------------------------------------------
c	Open files to contain errors, changes in errors,
c	energy and coordination information
c
c	- error.dat  -> total error
c	- sperr.dat  -> coordination error
c	- sqerr.dat  -> S(q) error
c	- grerr.dat  -> g(r) error
c	- engerr.dat -> energy error
c
c	- sqchn.dat  -> change in S(q) error
c	- grchn.dat  -> change in g(r) error
c	- sqchn.dat  -> change in coordination error
c	- engchn.dat -> change in energy error
c
c	- frsp2.dat  -> fraction of atoms with 3 nn
c	- frsp3.dat  -> fraction of atoms with 4 nn
c
c	- energy.dat -> total energy of system
c       --------------------------------------------------


        write(errfile,44) numbfile
  44    format('error',i2.2,'.dat')

        open(44,file=errfile,status='unknown')



	write(errfile,45) numbfile
  45	format('frnmc',i2.2,'.dat')

	open(45,file = errfile, status='unknown')

        write(errfile,48) numbfile
  48    format('frsp3',i2.2,'.dat')

        open(48,file = errfile, status='unknown')

        write(errfile,49) numbfile
  49    format('sperr',i2.2,'.dat')

        open(49,file = errfile, status='unknown')



        write(errfile,46) numbfile
  46    format('sqerr',i2.2,'.dat')

        open(46,file = errfile, status='unknown')


	write(errfile,64) numbfile
  64    format('grerr',i2.2,'.dat')

	open(64,file = errfile, status='unknown')



        write(enfile,52) numbfile
  52    format('energy',i2.2,'.dat')

        open(52,file = enfile, status='unknown')

        write(enfile,54) numbfile
  54    format('engerr',i2.2,'.dat')

        open(54,file = enfile, status='unknown')


        write(errfile,55) numbfile
  55    format('sqchn',i2.2,'.dat')

        open(55,file = errfile, status='unknown')


        write(errfile,65) numbfile
  65    format('grchn',i2.2,'.dat')

        open(65,file = errfile, status='unknown')


        write(errfile,57) numbfile
  57    format('spchn',i2.2,'.dat')

        open(57,file = errfile, status='unknown')

        write(errfile,58) numbfile
  58    format('engchn',i2.2,'.dat')

        open(58,file = errfile, status='unknown')






c       --------------------------------------------------
c       Write out simulation variables
c       --------------------------------------------------


        call fdate(date)

        write(21,704)
  704   format('Hybrid Reverse Monte Carlo')



        write(21,701) date
  701   format(/ 'Simulation Started: ',A24)


       write(21,700) numbfile, npre,irun
     1,nmol,rho,hdcore
     2,nptssq,sqerror,delq,nqstart,nqfinish,nqpts
     3,stpszinp,iseed
     4,istart
     6,radcordn,frcordn,nmcordn, wfcordn
     7, nnlist_option


 700  format(/,10x,'simulation run number                 = ',i8
     1,//,10X,'number of equilibriation steps             = ',i8
     1,/,10X,'number of steps in main run                = ',  i8
     2,//,10X,'number of atoms                            = ', i8
     2,/,10X,'reduced number density                     = ',  f8.5
     2,/,10X,'hard sphere core diameter                  = ',  f8.5
     3,//,10X,'number of experimental points in S(q)      = ', i8
     3,/,10X,'S(q) experimental error                    = ',  f8.5
     3,/,10X,'delq - spacing of experimental S(q)        = ',  f8.5
     3,/,10X,'first data point fitted                    = ',  i8
     3,/,10X,'last data point fitted                     = ',  i8
     3,/,10X,'number of points used in fast fourier tran = ',  i8
     4,//,10X,'step size for random displacement          = ', f8.5
     4,/,10X,'random number SEED                         = ',  i8
     5,/,10X,'option for starting configuration          = ',  i8
     7,/,10X,'radius of coordination shell               = ', f8.5
     7,//,10X,'required fraction of atoms with given coord= ',  f8.5
     7,/,10X,'coordination number                        = ',  i8
     8,/,10x,'coordination weighting factor              = ',  f8.5
     7,//,10x,'NN LISTING OPTION                          = ',  i8)


      write(21,710)
  710 format(//,'Equalibration Multi-Stages Options')

      write(21,705)
     1,sq_option, sp_option, en_option
     2,gr_option, tempK, lengthstage, lengthstage*npre

  705 format(//,10X,'---=== STAGE 1 OPTIONS ===--- '
     1,/,10x,'sq_option                                   : ',  l2
     1,/,10x,'sp_option                                   : ',  l2
     1,/,10x,'en_option                                   : ',  l2
     2,/,10x,'gr_option                                   : ',  l2
     2,//,10x,'Temperature [K]                             : ',  f10.2
     2,/,10x,'Stage 1 Finishing fraction of npre          : ',  f8.2
     2,/,10x,'Stage 1 Finishing Step                      : ',  f14.2)

      write(21,706)
     1,tempK1, lengthstage1, lengthstage1*npre

  706 format(//,10X,'---=== STAGE 2 OPTIONS ===--- '
     1,/,10x,'Temperature [K]                             : ',  f10.2
     1,/,10x,'Stage 2 Finishing fraction of npre          : ',  f8.2
     1,/,10x,'Stage 2 Finishing Step                      : ',  f14.2)

      write(21,707)
     1,tempK2, lengthstage2, lengthstage2*npre

  707 format(//,10X,'---=== STAGE 3 OPTIONS ===--- '
     1,/,10x,'Temperature [K]                             : ',  f10.2
     1,/,10x,'Stage 3 Finishing fraction of npre          : ',  f8.2
     1,/,10x,'Stage 3 Finishing Step                      : ',  f14.2)

      write(21,708)
     1,tempK3, npre

  708 format(//,10X,'---=== STAGE 4 OPTIONS ===--- '
     1,/,10x,'Temperature [K]                             : ',  f10.2
     1,/,10x,'Stage 4 Finishing faction of npre           :     1.00'
     1,/,10x,'Stage 4 Finishing Step                      : ',  i8)





c       --------------------------------------------------
c
c       Write out input Experimental S(q)
c
c       Experimental data range from
c
c       q1 = (nqstart - 1)*delq  to  qlast = (nqfinish - 1)*delq
c
c       the input s(q) data file is assumed to start at q = 0
c
c       --------------------------------------------------

	nptsexpt = (nqfinish - nqstart) + 1


	do k = 1,nptssq
	  read(11,*) q,sq
	  if((k.ge.nqstart).and.(k.le.nqfinish)) then
	    kk = k - nqstart+1
	    qexpt(kk)   = q
	    sqexpt(kk)  =  sq
	    write(33,102) qexpt(kk),sqexpt(kk)
 102        format(f9.6,3X,f9.6)
	    sqerr(kk)  = sqerror
	  endif
        end do



	return
	end



c--------------------------------------------------------------------
        subroutine CLOCKER

c       --------------------------------------------------
c 	Timing routine write start time and finishing time
c	in the hrmc.out files
c
c 	MAIN --> CLOCKER
c
c       --------------------------------------------------

	include 'rmcen.h'
	integer time, tdiff
	integer clock_finish
	integer clock_diff
	character*24 date




	if(nmcstep.eq.0) then
	  clock_start = time()

	elseif((nmcstep+npre).eq.(irun+npre+1)) then

	  call fdate(date)

	  tdiff = float(time()-clock_start)


	  write(21,702) date
  702     format(/ 'Simulation Ended: ',A24)
	  write(21,703) tdiff/60
  703     format(/ 'Time taken [Min]: ',i8)



	end if

	return
	end



c---------------------------------------------------------------------------
        subroutine CELLSTRT

c       --------------------------------------------------------------
c       Determine the starting cell structure which can be either
c	a randomly generator config or input from the initial.xyz file
c       --------------------------------------------------------------


        include 'rmcen.h'


c       -----------------------------
c       Set up starting configuration
c       -----------------------------
	if(istart.eq.1) then

	write(21,10)
  10    format(/,10x,'Initial configuration: initial.xyz')

	call INITIAL_CONFIG


	else if(istart.eq.2) then

	write(21,12)
  12    format(/,10x,'Initial configuration: random generator')

	call INITIAL_CONFIG

	endif



	return
	end



c---------------------------------------------------------------------------
	subroutine CONSTANT

c       ------------------------------------------------------------
c       Define constants for simulation for potentials, S(q)
c	tranform and cell dimensions
c       ------------------------------------------------------------

        include 'rmcen.h'

	real pi
	parameter (pi=3.14152653589793)

	integer i, j
	real r, frac, recip


c	-------------------------------------------------
c       calculate constants for G(r) and S(q) calculation
c       -------------------------------------------------

	delr     =   2*pi/(delq*(2*nqpts-2))
	delrinv  =   1.0/delr
	prodel   =   2.0*3.14159265*delr*rho
	hdcoresq =   hdcore*hdcore
        wf_energy =  2/(0.0000862*tempK)


	mpwrite = npre/5
	if(npre.lt.5) then
	  mpwrite = 1
 	end if


c	------------------------------
c       initialize Stepsize from input
c       ------------------------------
        stepsize = stpszinp


c       -------------------------------------------------
c	Energy Potential Constants
c       -------------------------------------------------

c       CARBON EDIP PARAMETERS
c       ======================

	C_low = 1.547
        C_high = 2.27
        C_low_p = 1.48
        C_high_p = 2.00
        C_alpha = 1.544

        C_aa      = 20.0853862863495
        C_bb      = 0.827599951322299
        C_beta    = 0.0490161172713279
        C_sigma   = 1.25714643580808
        C_a1      = 1.89225338775144
        C_a2      = 0.169794491000172

        C_xmu     = 0.25
        C_xlam    = 66.5
        C_tau1    = -15.0
        C_tau2    = 6.0
        C_lambda1 = 19.86
        C_lambda2 = 0.30
        C_gamma   = 1.3542
        C_qq      = 3.50
        c0        = 3.2
        zrep2     = 0.06
        zdih      = 0.30


c       SILICON EDIP PARAMETERS
c       =======================
	S_u1      = -0.165799
	S_u2      = 32.557
	S_u3      = 0.286198
	S_u4      = 0.66
	S_a1      = 7.9821730
	S_a2      = 3.1213820
	S_lambda  = 1.4533108
	S_q0      = 312.1341346
	S_alpha   = 3.1083847
	S_B       = 1.5075463
	S_C       = 2.5609104
	S_gamma   = 1.1247945
	S_mu      = 0.6966326
	S_p       = 1.2085196
        S_sigma   = 0.5774108
	S_n       = 0.2523244
	S_beta    = 0.0070975



c	SILICON STILLINGER-WEBER PARAMETERS
c       -----------------------------------

c	Modified SW Potential
c	=====================

	if(edip_type.eq.2) then

          W_eta = 1.64833
          W_A = 7.049556277
          W_B = 0.6022245584
          W_sigma = 2.0951
          W_p = 4
          W_alpha = 1.8
          W_lambda = 31.5
          W_gamma = 1.2

	end if


c	Original SW Potential
c	=====================

        if(edip_type.eq.3) then

          W_eta = 2.16826
          W_A = 7.049556277
          W_B = 0.6022245584
          W_sigma = 2.0951
          W_p = 4
          W_alpha = 1.8
          W_lambda = 21.0
          W_gamma = 1.2

        end if


c       -------------------------------------------------
c       Cutoff distances for potentials for nn
c	- 0 is carbon EDIP
c	- 1 is silicon EDIP
c	- 2 is the original silicon SW potential
c	- 3 is the modified silicon SW potential
c       -------------------------------------------------

	if(edip_type.eq.0) then
	  redip = 3.4
	end if

	if(edip_type.eq.1) then
	  redip = S_a2 + 0.01
	end if

	if(edip_type.eq.2.or.edip_type.eq.3) then
	  redip = W_alpha * W_sigma+0.01
	end if


c	----------------------------------
c       calculate number of points in G(r)
c       ----------------------------------
	nptsgr = cellmax/delr + 0.5
	rmax   = (nptsgr-1)*delr + delr/2.0
	rmaxsq = rmax*rmax

	igrstart = nptsgr+1
	igrend   = nqpts

	sqconst  = 4*pi*rho*(delr**2)/(delq)



c	-------------------------------
c	Determine Pore Cell Unit Length
c   	-------------------------------

	po_lcell = xl/po_res

	if(pore_option.eq.1) then
        if(scrwrite.eq.1) then
	print*,'Pore Cell resolution :', po_res
	print*,'Pore Unit length     :',po_lcell
        print*,' '
        end if
        end if



	write(21,10) delr
 10     format(/,10x,'Spacing in r for G(r) = ',f12.9)

	write(21,11) rmax
 11     format(/,10x,'rmax for G(r) is = ',f9.6)

	write(21,12) nptsgr,igrstart,igrend
 12     format(/,10x,'number of calculated points in G(r) = ',i4
     1,/,10X,'starting point of G(r) extension    = ',i4
     2,/,10X,'end point of G(r) extension         = ',i4)


c	------------------------------------------------------
c       create look up table for normalization factor for g(r)
c       ------------------------------------------------------

	do i = 1,igrend
	  r = (i-1)*delr
	  grnormlu(i) = prodel*r*r*nmol
        end do


c 	--------------------------------------------
c       create asymptot g(r) from igrstart to igrend
c       --------------------------------------------

	do j = igrstart,igrend
	  grold(j) = 1
	  grnew(j) = 1
	end do


c	---------------
c	read in expt gr
c	---------------

	if(nptsgr_expt.gt.nptsgr) nptsgr_expt = nptsgr

	do i = 1, nptsgr_expt
	  read(66,*) r, grexpt(i)
        end do


	return
	end



c----------------------------------------------------------------------------
	subroutine INITGRCD

c       ------------------------------------------------------------
c       Initialization rountine which calculates/determines
c       - Coordination and nn information from initial config
c       - Initial g(r)
c       - Initial system energy (via n^2 brute force)
c       - Checks simulation nn list routine by n^2 brute force at
c         the end of the main run.
c
c       ------------------------------------------------------------




        include 'rmcen.h'


        integer iset,jset,i,j,k, nnbin,igr, ic, ii1,jj1,kk1

	real expz, recip, frac
	real xu,yu,zu,xposi,yposi,zposi
        real rsq,rdist,grnorm
	integer nnavg, numsp3, ncord_check(max_atoms)
	integer adder1, temp1
	integer i_plus, i_minus, j_plus, j_minus, k_plus
	integer k_minus, po_surface_check
	real temp_x, temp_y, temp_z
	real temp2, temp3,temp4, temp5, temp6, t2B,t3B

	real fracsp3,xsp3
        real energy_sum

	real energy_check(max_atoms), avg_check(max_atoms)

	real RCUT, ONE_THIRD, rhoij, cos_x_ij, cos_y_ij
	real cos_z_ij, one_o_a, expo, gam_o_a_ij, exp_gam_ij
	real r_to_minusp, term1, A_EPS, rik, rhoik, cos_x_ik
	real cos_y_ik, cos_z_ik, one_o_a_ik, gam_o_a_ik
	real fact, cos_jik, cos_p_1o3, xi, yi, zi, xij, yij
	real zij, xik, yik, zik
	integer counterA, counterB


c	------------------------------------------------
c	Copy atomic nn, energies and pore grid occupancy
c	array to new locations for a later comparison
c	against N^2 brute force calc
c       ------------------------------------------------

	if(nstage.eq.2) then

	  do i=1, nmol
	    energy_check(i) = energy_atom(i)
	    ncord_check(i) = ncord_b(i)
	  end do

	  do i = 1, po_res
            do j = 1, po_res
              do k= 1, po_res

                po_cell_check(i,j,k) = po_cell(i,j,k)


              end do
            end do
          end do

          po_surface_check = po_surface_old

	endif


c	----------------------
c	Zero pore cell tensors
c	----------------------

        do i = 1, po_res
          do j = 1, po_res
            do k= 1, po_res

            po_cell(i,j,k) = 0
            po_cellA(i,j,k) = 0
            po_cellB(i,j,k) = 0

            end do
          end do
        end do


c	-------------------------------
c       set g(r) number counter to zero
c       -------------------------------
	do i = 1,nptsgr
	  nn(i)=0
	  grfinal(i)=0.0
	end do

c	------------------------
c       zero energy of each atom
c       ------------------------
        do i = 1, nmol
          energy_atom(i) = 0.0
	end do

c	----------------
c       zero energy sums
c       ----------------
        old_energy_total = 0
        new_energy_total = 0


c	----------------------------------------------------
c       Set coordination number arrays to zero
c
c	ncord -> coordination as defined by potential cutoff
c	ncord_b ->  coordination as defined by rmol radius
c	z(i) -> average coordination used in EDIP potentials
c	avg_ncord -> same as z(i)
c       ----------------------------------------------------

	do i = 1,nmol
          ncord(i) = 0
          ncord_b(i) = 0
	  z(i) = 0
	  avg_ncord(i) = 0.0
	end do


c	------------------------------
c	Zero total number of pores sum
c	------------------------------
	po_total_old = 0


c	------------------------------------------------------------
c       calculate number of atoms between r and r + dr: {nn(r,r+dr)}
c       ------------------------------------------------------------


	do i = 1,nmol

	  xposi = xc(i)
	  yposi = yc(i)
	  zposi = zc(i)


c       +++++++++++++++++++++++++++++++++++++++++++++++++++
c	Determine initial pore cell
c	- the +1 is that arrays beginning at 1 not 0 in F90
c	+++++++++++++++++++++++++++++++++++++++++++++++++++

          xindex = (int(xc(i)/po_lcell))+1
          yindex = (int(yc(i)/po_lcell))+1
          zindex = (int(zc(i)/po_lcell))+1

          po_cell(xindex,yindex,zindex)=po_cell(xindex,yindex,zindex)+1
         po_cellA(xindex,yindex,zindex)=po_cellA(xindex,yindex,zindex)+1
          po_xatom(i) = xindex
          po_yatom(i) = yindex
          po_zatom(i) = zindex

          temp1 = po_cell(xindex,yindex,zindex)


          if(temp1.eq.1) then
          po_total_old = po_total_old + 1
          end if

c	+++++++++++++++++++++++++++++++++++++++++++++++++++


	  do j = (i+1),nmol

c	---------------
c       Minimum imaging
c       ---------------

	    xu = xc(j) - xposi
	    yu = yc(j) - yposi
	    zu = zc(j) - zposi

c	---------------------------------------------------------
c       Select appropriate minimum imaging conditions wrt lattice
c	- Only rectangular systems allowed
c       ---------------------------------------------------------

	    xu = xu - (int(xu/xl2)*xl)
	    yu = yu - (int(yu/yl2)*yl)
	    zu = zu - (int(zu/zl2)*zl)

	    rsq = xu*xu + yu*yu + zu*zu

	    if(rsq.lt.rmaxsq) then
	      rdist = sqrt(rsq)

c	---------------------------------------------------------
c       Separation histogram for g(r) calculation
c	---------------------------------------------------------

	      nnbin = rdist*delrinv + 1.5
	      if(nnbin.le.nptsgr) nn(nnbin) = nn(nnbin)+1


c	------------------------------
c       calculate coordination numbers
c       ------------------------------

c	Coordination based on rmol
c	==============================

              if(rdist.le.radcordn) then
	        ncord_b(i)=ncord_b(i)+1
	        nnlist_b(i,ncord_b(i)) = j
                ncord_b(j)=ncord_b(j)+1
                nnlist_b(j,ncord_b(j)) = i
	      end if

c       Coordination based on potentail cutoffs
c	=======================================

	      if(rdist.le.redip) then
	        ncord(i)=ncord(i)+1
	        nnlist(i,ncord(i)) = j
	        ncord(j)=ncord(j)+1
	        nnlist(j,ncord(j)) = i

                dr(i,ncord(i))= rdist
	        dr(j,ncord(j))= rdist

	        dxdr(i,ncord(i)) = -xu/rdist
	        dxdr(j,ncord(j)) =  xu/rdist
	        dydr(i,ncord(i)) = -yu/rdist
	        dydr(j,ncord(j)) =  yu/rdist
	        dzdr(i,ncord(i)) = -zu/rdist
	        dzdr(j,ncord(j)) =  zu/rdist

		if(edip_type.eq.0) then
	          if(rdist.gt.C_high-0.001) then
                    avg_ncord(i) = avg_ncord(i) + 0.0
	            avg_ncord(j) = avg_ncord(j) + 0.0
                  elseif(rdist.lt.C_low+0.001) then
                    avg_ncord(i) = avg_ncord(i) + 1.0
	            avg_ncord(j) = avg_ncord(j) + 1.0
                  else
                    frac=(rdist-C_low)/(C_high-C_low)
                    recip= 1.0/(1.0-frac**-3)
                    expz= exp(C_alpha*recip)
                    avg_ncord(i) = avg_ncord(i) + expz
	            avg_ncord(j) = avg_ncord(j) + expz
	          end if
                end if

		if(edip_type.eq.1) then
		  if(rdist.gt.S_a2-0.001) then
                    avg_ncord(i) = avg_ncord(i) + 0.0
                    avg_ncord(j) = avg_ncord(j) + 0.0
                  elseif(rdist.lt.S_C+0.001) then
                    avg_ncord(i) = avg_ncord(i) + 1.0
                    avg_ncord(j) = avg_ncord(j) + 1.0
                  else
                    frac=(rdist-S_C)/(S_a2-S_C)
                    recip= 1.0/(1.0-frac**-3)
                    expz= exp(S_alpha*recip)
                    avg_ncord(i) = avg_ncord(i) + expz
                    avg_ncord(j) = avg_ncord(j) + expz
                  end if
		end if

	      endif
            endif
          end do
        end do


c	---------------------------------------------------------
c       Carbon EDIP additional calculations
c	---------------------------------------------------------

        if(edip_type.eq.0) then
	  call EDIP_CUTOFF
	end if


c	---------------------------------------------------------
c       Output pore occupancy array to rmcprXX.xyz
c	---------------------------------------------------------

	do i = 1, po_res
          do j = 1, po_res
            do k= 1, po_res

            if(po_cell(i,j,k).eq.0) then
              temp_x = (i*po_lcell) - 0.5*po_lcell
              temp_y = (j*po_lcell) - 0.5*po_lcell
              temp_z = (k*po_lcell) - 0.5*po_lcell

              write(81,10) temp_x,temp_y,temp_z
  10          format(3(f8.4,1x))

            end if

            end do
          end do
        end do


c	----------------------
c       calculate initial g(r)
c       ----------------------
	do i = 1,nptsgr
	  grnorm = grnormlu(i)

	  if(grnorm.ne.0) then
	    grold(i) = nn(i)/grnorm
	  else
	    grold(i) = 0.0
	  endif
        end do


c       -----------------------------------------------
c       calculate number of sp2 and sp3 atoms
c       -----------------------------------------------

	numsp3  = 4
	fracsp3 = 1.0 - frcordn

	numbcord = 0
	ncordsp3 = 0

	do i= 1,nmol
	  if(ncord_b(i).eq.nmcordn) then
	    numbcord = numbcord + 1
	  endif
	  if(ncord_b(i).eq.numsp3) then
	    ncordsp3 = ncordsp3  + 1
	  endif
        end do


c	------------------------------------
c	Calculate fraction sp2 sp3 and error
c	------------------------------------

	frmc = real(numbcord)/nmol
	fsp3 = real(ncordsp3)/nmol
	xoldcord = ((frmc-frcordn)**2)/(wfcordn**2)


c	Store sum of sp2 and sp3 coordination
c	-------------------------------------

	old_sum_sp2 = numbcord
	old_sum_sp3 = ncordsp3



c	---------------------------------------------------------
c       Energy Potential Routines
c	- Calculates the initial total energy
c	---------------------------------------------------------


c       CARBON EDIP POTENTIAL
c       =====================

	if(edip_type.eq.0) then

        do i=1, nmol

          selector = i
          call coord_terms

	    C_a12 = C_a1 + C_a2*z(i)
	    C_tau = 1.0 - z(i)/12.0 * (1.0 + tanh(C_tau1+C_tau2*z(i)))

c       Two Body Term
c       -------------
        do jj1=1, ncord(i)

		if(dr(i,jj1).lt.C_a12-0.001) then
		rij = dr(i,jj1)
                bond = exp(-C_beta*z(i)*z(i))

        energy_atom(i)=energy_atom(i) +C_aa*(C_bb/rij**4-bond)
     :                     *exp(C_sigma/(rij-C_a12))


c	Three Body Term
c	---------------


              do kk1 = jj1+1, ncord(i)

                if(dr(i,kk1).lt.C_a12-0.001) then

	   cosi = dxdr(i,jj1)*dxdr(i,kk1)+dydr(i,jj1)*dydr(i,kk1)
     :          +dzdr(i,jj1)*dzdr(i,kk1)


	   arg12= C_gamma/(dr(i,jj1)-C_a12) + C_gamma/(dr(i,kk1)-C_a12)
           zexpgam=exp(arg12-C_xmu*(z(i)-4.0)*(z(i)-3.0-0.069/C_xmu))
	   theta = C_xlam/C_qq*(1.0-exp(-C_qq*(cosi+C_tau)**2))

	   energy_atom(i) = energy_atom(i) + zexpgam*theta


                end if
 	        end do
  	      end if
	    end do

	 old_energy_total = old_energy_total + energy_atom(i)

 	 end do

        end if




c       SILICON EDIP POTENTIAL
c       ======================

	if(edip_type.eq.1) then

	do i=1, nmol

	  z(i) = avg_ncord(i)
          S_tau = S_u1+S_u2*(S_u3*exp(-S_u4*z(i))-exp(-2*S_u4*z(i)))
          S_que = S_q0*exp(-S_mu*z(i))


c       Two Body Term
c       -------------
        do jj1=1, ncord(i)

                if(dr(i,jj1).lt.S_a2-0.001) then

                rij = dr(i,jj1)
                bond = exp(-S_beta*z(i)*z(i))
        energy_atom(i)=energy_atom(i) +S_a1*(((S_B/rij)**S_p)-bond)
     :                     *exp(S_sigma/(rij-S_a2))


c       Three Body Term
c       ---------------


              do kk1 = jj1+1, ncord(i)

                if(dr(i,kk1).lt.S_a2-0.001) then

           cosi = dxdr(i,jj1)*dxdr(i,kk1)+dydr(i,jj1)*dydr(i,kk1)
     :          +dzdr(i,jj1)*dzdr(i,kk1)


           arg12 = S_gamma/(dr(i,jj1)-S_a2)+S_gamma/(dr(i,kk1)-S_a2)
	   S_term1 = (1-exp(-S_que*(cosi+S_tau)**2))
	   S_term2 = S_n*S_que*(cosi+S_tau)**2
	   S_term3 = S_lambda*(S_term1+S_term2)*exp(arg12)


           energy_atom(i) = energy_atom(i) + S_term3


                end if
                end do
              end if

            end do

         old_energy_total = old_energy_total + energy_atom(i)

         end do

	end if



c       SILICON SW POTENTIAL
c       ======================

	if(edip_type.eq.2.or.edip_type.eq.3) then

	RCUT = (W_alpha * W_sigma)
	ONE_THIRD = (1.0/ 3.0)
	A_EPS = (W_A * W_eta)

	do i=1, nmol

	  T2B = 0.0
	  T3B = 0.0

	  xi=xc(i)
          yi=yc(i)
          zi=zc(i)


c       Two Body Term
c       -------------
        do jj1=1, ncord(i)

        j = nnlist(i,ncord(jj1))


          rij = dr(i,jj1)


          if(rij.lt.RCUT) then

             rhoij=rij/W_sigma


 	     cos_x_ij=dxdr(i,jj1)
             cos_y_ij=dydr(i,jj1)
             cos_z_ij=dzdr(i,jj1)

            one_o_a =1.0/(rhoij-W_alpha)
            expo=exp(one_o_a)
            gam_o_a_ij=W_gamma*one_o_a
            exp_gam_ij=exp(gam_o_a_ij)
            r_to_minusp= rhoij**(-1*W_p)

            term1=A_EPS*(W_B*r_to_minusp-1.0)*expo

            energy_atom(i) = energy_atom(i) + term1*0.5


c      Three Body Term
c      ---------------

           do kk1 = jj1+1, ncord(i)

           k = nnlist(i,ncord(kk1))
           rik = dr(i,kk1)

           if(rik.lt.RCUT) then

              rhoik=rik/W_sigma
              cos_x_ik=dxdr(i,kk1)
              cos_y_ik=dydr(i,kk1)
              cos_z_ik=dzdr(i,kk1)

              one_o_a_ik=1.0/(rhoik-W_alpha)
              gam_o_a_ik=W_gamma*one_o_a_ik
              fact = W_eta*W_lambda*exp(gam_o_a_ik)*exp_gam_ij

            cos_jik = (cos_x_ij*cos_x_ik)+(cos_y_ij
     :      * cos_y_ik) + (cos_z_ij*cos_z_ik)

              cos_p_1o3=cos_jik+ONE_THIRD

              energy_atom(i) = energy_atom(i) + fact*(cos_p_1o3**2)

            end if

          end do
          end if
          end do

        old_energy_total = old_energy_total + energy_atom(i)

        end do

	end if



c	------------------------------
c	Calculate average coordination
c	------------------------------

	nnavg = 0

	do i=1, nmol
	  nnavg = nnavg + ncord_b(i)
        end do

	avgnn = real(nnavg)/nmol



c      ---------------------------
c      Store initial configuration
c      ---------------------------

	do i=1, nmol
	  xstart(i) = xc(i)
	  ystart(i) = yc(i)
	  zstart(i) = zc(i)
  	end do


c       ------------------------------------
c       Set number of accepted moves to zero
c       ------------------------------------
	mvsacpt = 0


c	--------------------------------------------------
c	Check if energy and coordn are ok after main stage
c	--------------------------------------------------

     	if(nstage.eq.2) then

     	if(scrwrite.eq.1) then
     	print*,''
	print*,'ERROR CHECKING'
	end if

 	adder1 = 0
	do i=1, nmol
          if(abs(energy_check(i)-energy_atom(i)).gt.0.00001) then
	    print*,' problem with energy:', i
	    print*,' energy_atom ', energy_atom(i)
	    print*,' energy_check ', energy_check(i)
	    print*,' Difference:',energy_atom(i)-energy_check(i)
	    adder1 = adder1 + 1
	  endif
	end do
	if(scrwrite.eq.1) then
	print*,'Sum of Energy Errors:',adder1
	end if

	adder1 = 0
        do i=1, nmol
          if(abs(ncord_check(i)-ncord_b(i)).gt.0.000001) then
            print*,' problem with ncord:', i
            print*,' ncord_b:', ncord_b(i)
            print*,' ncord_check:', ncord_check(i)
	    adder1 = adder1 + 1
          endif
	end do
	if(scrwrite.eq.1) then
	print*,'Sum of ncord_b Errors:',adder1
        end if

	end if

	return
	end




c----------------------------------------------------------------------------
	subroutine EDIP_CUTOFF

	include 'rmcen.h'

	integer i, jj
	real frac, recip, expf, arg


c	-------------------------
c       Basic z with p(r) cutoffs
c       -------------------------

	do i=1, nmol
	if(avg_ncord(i).lt.4.0) then
	  do jj=1, ncord(i)
	    rij=dr(i,jj)
	    if(rij.gt.C_high_p-0.001) then
	      f(i,jj)=0.0

 	    elseif(rij.lt.C_low_p+0.001) then
	      f(i,jj)=1.0

	    else
	      frac=(rij-C_low_p)/(C_high_p-C_low_p)
	      recip=1.0/(1.0-frac**-3)
	      expf= exp(C_alpha*recip)

	      f(i,jj)= expf

	    endif
	  end do
        end if
	end do



c	----------------------------------
c       Determine Pi for sp1 and sp2 atoms
c       ----------------------------------

	do i=1, nmol
 	if(avg_ncord(i).lt.3.0) then
	  g(i) = 1.0
	elseif (avg_ncord(i).gt.4.0) then
	  g(i) = 0.0
	else
	  arg = avg_ncord(i) -3.0
	  g(i) = (arg*arg - 1.0)**2
	end if

	end do


c	----------------------------------
c       Determine Pi3 for sp2 atoms
c       ----------------------------------

	do i=1, nmol
	if((avg_ncord(i).lt.2.0).or.(avg_ncord(i).gt.4.0)) then
	  g3(i) = 0.0
	else
	  arg = avg_ncord(i) -3.0
	  g3(i)= (arg*arg -1.0)**2
	end if

	end do


c       --------------------------
c       Determine Pi2 for sp atoms
c       --------------------------

	do i=1,nmol
	if((avg_ncord(i).lt.1.0).or.(avg_ncord(i).gt.3.0)) then
	  g2(i)=0.0
	else
	  arg = avg_ncord(i)-2.0
	  g2(i)= (arg*arg -1.0)**2
	end if

	end do

	return
	end



c----------------------------------------------------------------------------
	subroutine COORD_TERMS

 	include 'rmcen.h'

	integer ab

	z(selector) = avg_ncord(selector)

 	call DIHEDRAL_TERM
	call REPULSION _TERM
	call LINEAR_TERM

	return
	end



c-----------------------------------------------------------------------------
	subroutine LINEAR_TERM

	include 'rmcen.h'
	integer iii, j, jj, kk, k1, k2
	real rx(2,3), rr(2), ff(2), cc, gg, ff2


	iii = selector

	if(avg_ncord(iii).gt.3.0) return

	do jj=1, ncord(iii)
	j=nnlist(iii,jj)
	rij=dr(iii,jj)
	if ((avg_ncord(j).lt.4.0).and.(rij.gt.C_low_p).and.(rij.lt.c0)) then

	  do kk=1, ncord(iii)
	  if ((kk.ne.jj).and.(dr(iii,kk).lt.C_high_p)) then

	  rx(1,1) = dxdr(iii,jj)
	  rx(2,1) = dxdr(iii,kk)
	  rx(1,2) = dydr(iii,jj)
	  rx(2,2) = dydr(iii,kk)
	  rx(1,3) = dzdr(iii,jj)
	  rx(2,3) = dzdr(iii,kk)

	  rr(1) = dr(iii,jj)
	  rr(2) = dr(iii,kk)
	  cc = rr(1) - c0

	  ff(1) = (1.0 - f(iii,jj)) * cc * cc
	  ff(2) =        f(iii,kk)
	  ff2 = ff(1) * ff(2)

	  gg = g2(iii) * g(j)

	  do k1=1,2
	     k2= 3-k1

	  dot = 0.0
	  dot=rx(k1,1)*rx(k2,1)+rx(k1,2)*rx(k2,2)+rx(k1,3)*rx(k2,3)

	  end do

          z(iii) = z(iii) + zrep2 * gg * (1.0-dot*dot) * ff2


       end if
       end do

       end if
       end do

       return
       end



c-----------------------------------------------------------------------------
	subroutine REPULSION_TERM

	include 'rmcen.h'
	integer iii, j, jj, kk, mm, k1, k2, k3
        real  xk(3), rx(3,3),rr(3), ff(3), cc, gg, ff123

	iii = selector

	if(avg_ncord(iii).gt.4.0) return

	do jj = 1, ncord(iii)
	j=nnlist(iii,jj)
	rij=dr(iii,jj)
	if((avg_ncord(j).lt.4.0).and.(rij.gt.C_low_p).and.(rij.lt.c0)) then

	  do kk=1, ncord(iii)
	  if((kk.ne.jj).and.(dr(iii,kk).lt.C_high_p)) then

	    do mm =kk+1, ncord(iii)
	    if((mm.ne.jj).and.(dr(iii,mm).lt.C_high_p)) then

	    rx(1,1)=dxdr(iii,jj)
	    rx(2,1)=dxdr(iii,kk)
	    rx(3,1)=dxdr(iii,mm)
	    rx(1,2)=dydr(iii,jj)
	    rx(2,2)=dydr(iii,kk)
	    rx(3,2)=dydr(iii,mm)
	    rx(1,3)=dzdr(iii,jj)
            rx(2,3)=dzdr(iii,kk)
	    rx(3,3)=dzdr(iii,mm)

	    rr(1) = dr(iii,jj)
	    rr(2) = dr(iii,kk)
	    rr(3) = dr(iii,mm)

            cc = rr(1) - c0

	    ff(1) = (1.0-f(iii,jj))*cc*cc
	    ff(2) =      f(iii,kk)
	    ff(3) =      f(iii,mm)
	    ff123  = ff(1) * ff(2) * ff(3)

	    gg = g3(iii) * g(j)


            do k1=1,3
	      k2= mod(k1  ,3) + 1
	      k3= mod(k1+1,3) + 1

	      xk(1) = rx(k2,2)*rx(k3,3) - rx(k2,3)*rx(k3,2)
	      xk(2) = rx(k2,3)*rx(k3,1) - rx(k2,1)*rx(k3,3)
	      xk(3) = rx(k2,1)*rx(k3,2) - rx(k2,2)*rx(k3,1)

	      dot=rx(k1,1)*xk(1)+rx(k1,2)*xk(2)+rx(k1,3)*xk(3)

	    end do

            z(iii) = z(iii) +zrep2 * gg * dot*dot * ff123


	    end if
	    end do

	  end if
 	  end do

	end if
	end do

	return
	end

c-----------------------------------------------------------------------------
	subroutine DIHEDRAL_TERM

	include 'rmcen.h'
	integer iii, j, jj, kk, mm, ss, k1, k2, k3
        real xk(3), rx(3,3),rr(3), ff(3), cc, gg, ff4

	iii = selector

	if(avg_ncord(iii).gt.4.0) return

	do jj=1, ncord(iii)

	j=nnlist(iii,jj)
	if((avg_ncord(j).lt.4.0).and.(dr(iii,jj).lt.C_high_p)) then


	do kk=1, ncord(iii)
	if((kk.ne.jj).and.(dr(iii,kk).lt.C_high_p)) then


	  do mm=kk+1, ncord(iii)
	  if((mm.ne.jj).and.(dr(iii,mm).lt.C_high_p)) then

	    do ss=1, ncord(j)
	    if((nnlist(j,ss).ne.iii).and.(dr(j,ss).lt.C_high_p)) then


   	    rx(1,1)=dxdr(iii,kk)
            rx(2,1)=dxdr(iii,mm)
            rx(3,1)=dxdr(j,ss)
            rx(1,2)=dydr(iii,kk)
            rx(2,2)=dydr(iii,mm)
            rx(3,2)=dydr(j,ss)
            rx(1,3)=dzdr(iii,kk)
            rx(2,3)=dzdr(iii,mm)
            rx(3,3)=dzdr(j,ss)

	    rr(1) = dr(iii,kk)
	    rr(2) = dr(iii,mm)
	    rr(3) = dr(j,ss)

	    ff(1) = f(iii,kk)
	    ff(2) = f(iii,mm)
	    ff(3) = f(j,ss)

	    ff4 = ff(1) * ff(2) * ff(3) * f(iii,jj)

	    gg = g3(iii) * g3(j)

	    do k1=1,3
	      k2 = mod(k1  ,3) + 1
	      k3 = mod(k1+1,3) + 1

	      xk(1) = rx(k2,2)*rx(k3,3) - rx(k2,3)*rx(k3,2)
	      xk(2) = rx(k2,3)*rx(k3,1) - rx(k2,1)*rx(k3,3)
	      xk(3) = rx(k2,1)*rx(k3,2) - rx(k2,2)*rx(k3,1)


	      dot=rx(k1,1)*xk(1)+rx(k1,2)*xk(2)+rx(k1,3)*xk(3)


	    end do

	    z(iii) = z(iii) + zdih * gg * dot * dot * ff4

	  end if
	  end do
	end if
	end do
	end if
	end do
	end if
	end do

	return
	end



c-----------------------------------------------------------------------------
	subroutine INITLSQ

        include 'rmcen.h'


  	call GRFFT(grold,sqold)


	return
	end



c------------------------------------------------------------------------------
	subroutine MCARLOSTP

        include 'rmcen.h'

	move_rejected = .false.

        call MCARLGR1


c	-------------------------------------------------
c       If there is no hard core overlap calculate new sq
c       -------------------------------------------------
        if(.not.move_rejected) then

        if(sq_option) then

          call GRFFT(grnew,sqnew)

	endif


	  call MCARLOSQ
	endif




	return
	end



c---------------------------------------------------------------------------
        subroutine TOTAL_ERROR

c	---------------------------------------------------------------
c       Write out errors, energies and changes in those to file
c       ---------------------------------------------------------------

        include 'rmcen.h'

	integer total_steps, i



c	-----------------------------------------
c	Note: nmcsteps resets to zero at nstage 2
c   	-----------------------------------------
	total_steps = nmcstep
	if(nstage.eq.2) then
	  total_steps = total_steps + npre
        end if

c	-----------------
c	Write out to file
c	-----------------


c	===========
c	Total Error
c       ===========
	write(44,100) total_steps, xoldtt
  100	format(i9,2x, f20.8)


c	========
c	sq error
c	========
        write(46,510) total_steps, total_sq_error
  510   format(i9,2x, f20.8)


c	========
c       gr error
c       ========
	write(64,510) total_steps, total_gr_error


c	==================
c	coordination error
c	==================
	write(49,510) total_steps, total_cordn_error


c	============
c       energy error
c       ============
        write(54,513) total_steps, wf_energy*old_energy_total
  513   format(i9,2x, f20.8)


c	===============
c	fraction of sp2
c	===============
        write(45,45) total_steps, frmc
   45   format(i9,2x,f8.6)


c	===============
c	fraction of sp3
c	===============
        write(48,48) total_steps, fsp3
   48   format(i9,2x,f8.6)


c	============
c       total energy
c       ============
        write(52,511) total_steps, old_energy_total
  511   format(i9,2x, f20.8)


c	==================
c       Change in sq error
c       ==================
	write(55,555) total_steps, sq_change
  555	format(i9,2x, f20.8)


c	==================
c       Change in gr error
c       ==================
	write(65,555) total_steps, gr_change


c	============================
c	Change in coordination error
c	============================
        write(57,557) total_steps, sp_change
  557   format(i9,2x, f20.8)



c	======================
c	Change in energy error
c	======================
        write(58,558) total_steps, energy_change
  558   format(i9,2x, f20.8)



        return
        end




c---------------------------------------------------------------------------
	subroutine WRPOSN

        include 'rmcen.h'

	integer i

	do i=1,nmol
	  if(xc(i).gt.xl.or.yc(i).gt.yl.or.zc(i).gt.zl) then
            print*,'ERROR - ATOM IS OUTSIDE CELL'
	    print*,'Atom number:',i
	    print*,'xl,yl,zl:',xl,yl,zl
	    print*,'xc,yc,zc:',xc(i),yc(i),zc(i)
            STOP
          end if

	write(22,10) xc(i),yc(i),zc(i)
  10    format(3(f8.4,1x))
        end do


	return
	end




c---------------------------------------------------------------------------
	subroutine GRWRITE

        include 'rmcen.h'

	character *13 grfin, sqfin
	integer grlabel, qshift, j, k, kk
	real r, grnorm,gr(max_gr_points)
        real q, sqend(max_sq_data_points)


c	------------------------------------------
c	Final g(r) and S(q) averaged write to file
c       ------------------------------------------

        write(grfin,52) numbfile
  52    format('grfinal',i2.2,'.dat')
	open(52,file=grfin,status='unknown')


   	do j = 1, nptsgr
   	  r = (j-1) * delr
   	  if(grcounter.ne.0) then
   	    grfinal(j) = grfinal(j) / grcounter
   	  end if
   	  write(52,13) r, grfinal(j)
  13      format(f8.4,1x,f8.4)
   	end do

   	do j = nptsgr+1,nqpts
	  grfinal(j) = 1
	end do



c	---------------------------------------------------------
c       For last calculated g(r) and s(q) calculate s(q) based on
c       fourier transforming the g(r).
c	---------------------------------------------------------

        call GRFFT(grfinal, sqend)


        write(sqfin,34) numbfile
   34   format('sqfinal',i2.2,'.dat')
	open(34,file=sqfin,status='unknown')

	do kk=1, nptsexpt
	  qshift = nqstart + kk-1
	  q = (qshift-1)*delq
   	  write(34,14) q,sqend(kk)
   14	  format(f8.4,1X,f8.4)
    	end do

	close(34)
        close(52)



	return
	end



c---------------------------------------------------------------------------
	subroutine ENDTXT

        include 'rmcen.h'

	real frmvacpt

	if(nstage.eq.1) then

	  write(21,10) npre
  10      format(/,10x,'Number of MAIN STEPS        : ',i8)

          write(21,11) mvsacpt
  11      format(10x,'Number of accepted moves : ',i8)

          frmvacpt = real(mvsacpt)/real(npre)

	  write(21,12) frmvacpt
  12      format(10x,'Fraction of accepted moves : ',f8.6)

	end if



	if(nstage.eq.2) then
          write(21,13) irun
  13      format(10x,'Number of DATA Steps (equilibriated): ',i8)

	  write(21,14) mvsacpt
  14      format(10x,'Number of accepted moves             : ',i8)

          frmvacpt = real(mvsacpt)/real(irun)

	  write(21,15) frmvacpt
  15      format(10x,'Fraction of accepted moves : ',f8.6)



	end if


	return
	end



c---------------------------------------------------------------------------
	subroutine MCARLGR1

        include 'rmcen.h'


c       -----------------------------------------------------------------
c       Subroutine which chooses a particle at random, gives it a random
c       displacement and calculates the resulting change in the g(r) and
c       other quantities.  All axes orthognal.
c       -----------------------------------------------------------------


	real xoldi,yoldi,zoldi
	real xdispli,ydispli,zdispli
	real xposj,yposj,zposj,xu,yu,zu
	real rsqold,rold,rsqnew,rnew

	integer nnbin, iset, jset,  n, i, j, k, jgr
	integer i_plus, i_minus, j_plus, j_minus
	integer k_plus, k_minus
	integer i_plus2, i_minus2, j_plus2, j_minus2
	integer k_plus2, k_minus2

	integer po_surf_new, po_surf_old
	integer po_surf_change, tempA
	integer temp_x(14), temp_y(14), temp_z(14)


	real sjold(max_atoms),sjnew(max_atoms)
	real xrandm, ran2, grnorm



c	----------------------------------------------------------------
c	Set number of new nn for ichosen  + missing and extra nn to zero
c	----------------------------------------------------------------
	oldnn = 0
	newnn = 0


c	---------------------------
c       Set nn change array to zero
c       ---------------------------
	do i=1, nptsgr
	  nnch(i) = 0
   	end do


c	--------------------------------------------------------------
c       Set flag indicating whether a move is accepted to not accepted
c       --------------------------------------------------------------
	mvaptflg = 1


c	------------------------
c       choose a random particle
c       ------------------------
	xrandm = RAN2(iseed)
	ichosen = nmol*xrandm
	ichosen = ichosen+1
	if(ichosen.gt.nmol)   ichosen = nmol
	if(ichosen.lt.0)      ichosen = 1


c	-------------------------------------
c       Store previous position of particle i
c       -------------------------------------
	xoldi=xc(ichosen)
	yoldi=yc(ichosen)
	zoldi=zc(ichosen)


c	-------------------------------
c       Give atom a random displacement
c       -------------------------------
	xdispli=(RAN2(iseed)-.5)*stepsize
	ydispli=(RAN2(iseed)-.5)*stepsize
	zdispli=(RAN2(iseed)-.5)*stepsize


c	------------------------------------------------------------------
c       Observe period boundary conditions for new position: origin corner
c       ------------------------------------------------------------------
        xnewi = mod(xoldi  +xdispli+xl ,xl)
        ynewi = mod(yoldi  +ydispli+yl ,yl)
        znewi = mod(zoldi  +zdispli+zl ,zl)


c	-------------------------------------------
c	Determine new pore cell location of ichosen
c	-------------------------------------------
	xindex_new = (int(xnewi/po_lcell))+1
        yindex_new = (int(ynewi/po_lcell))+1
        zindex_new = (int(znewi/po_lcell))+1


c       -----------------------------------------------
c       Reject any moves that move into a pore grid
c	-----------------------------------------------
        if(pore_option.eq.1) then
          if(po_cellC(xindex_new,yindex_new,zindex_new).eq.1) then
            move_rejected = .true.
            return
          end if
        end if



c       ------------------------------------------------------------
c       Calculate change in g(r) due to change in position of atom i
c       ------------------------------------------------------------

	do j=1,nmol

	  if(j.ne.ichosen)  then
	    xposj = xc(j)
	    yposj = yc(j)
	    zposj = zc(j)

	    xu = xposj - xnewi
	    yu = yposj - ynewi
	    zu = zposj - znewi


c	=====================================
c       Apply minimum imaging to new postions
c       =====================================
   	    xu = xu - (int(xu/xl2)*xl)
	    yu = yu - (int(yu/yl2)*yl)
	    zu = zu - (int(zu/zl2)*zl)


	    rsqnew = xu*xu+yu*yu+zu*zu
	    sjnew(j) = 9000


c	=========================================
c       Reject any separation smaller than hdcore
c       =========================================
	    if(rsqnew.lt.hdcoresq) then
	      move_rejected = .true.
	      return
	    endif


c	==============================================
c       Check that rij < rmax; if not ignore the
c       contribution of rij to g(r) with sjnew(j)=9000
c       ==============================================
	    if(rsqnew.lt.rmaxsq) then
	      rnew = sqrt(rsqnew)
	      sjnew(j) = rnew

c	=============================================================
c       Generate nearest neighbour list of particle i in new position
c       =============================================================
	      if(rnew.lt.redip) then
	        newnn = newnn + 1
	        newlist(newnn) = j
	      endif
	    endif


c	=============================================================
c       Calculate contribution of particle i to g(r) for old position
c       =============================================================
	    xu = xposj - xoldi
	    yu = yposj - yoldi
	    zu = zposj - zoldi

c	=====================================
c       apply minimum imaging to old postions
c       =====================================
	    xu = xu - (int(xu/xl2)*xl)
	    yu = yu - (int(yu/yl2)*yl)
	    zu = zu - (int(zu/zl2)*zl)

	    rsqold = xu*xu + yu*yu + zu*zu
	    sjold(j) = 9000

	    if(rsqold.lt.rmaxsq) then
	      rold = sqrt(rsqold)
	      sjold(j) = rold


c	=============================================================
c       Generate nearest neighbour list of particle i in old position
c       =============================================================
	      if(rold.lt.redip) then
                oldnn = oldnn + 1
                oldlist(oldnn) = j
              endif
	    endif
	  endif
    	end do


c	----------------------------------------
c	Calculate change in coordination numbers
c	----------------------------------------
	if(nnlist_option) then
	  call COORDINATION_CHA
	else
	  call COORDINATION_CHB
	end if


c	---------------------------------------
c	Reject move if coordination unrealistic
c	---------------------------------------
 	if(move_rejected) then
	  return
	endif


c       ----------------------------------------
c       calculate change in g(r) - store in nnch
c       ----------------------------------------
	if(gr_option.or.sq_option) then
	  do i = 1,nmol
	    if(ichosen.ne.i) then
	      rold = sjold(i)
	      rnew = sjnew(i)

	      nnbin = (rold)*delrinv + 1.5
	      if(nnbin.le.nptsgr) then
	        nnch(nnbin) = nnch(nnbin)-1
	      end if

	      nnbin = (rnew)*delrinv + 1.5
	      if(nnbin.le.nptsgr) then
	        nnch(nnbin) = nnch(nnbin)+1
              end if

	    endif
	  end do
	endif



c       ------------------
c       calculate new g(r)
c       ------------------
	if(gr_option.or.sq_option) then
	  do i = 1,nptsgr
	    grnorm = grnormlu(i)
	    if(grnorm.ne.0) then
	      grnew(i) = (nn(i) + nnch(i))/grnorm
	    else
	      grnew(i) = 0.0
	    endif
  	  end do
	endif


	return
	end

c---------------------------------------------------------------------------
	subroutine QUICKSORT(quick_list, quick_sum)

	include 'rmcen.h'

c	------------------------------------------
c       Quicksort algorithm with duplicate removal
c       ------------------------------------------


	integer quick_list(50000)
	integer quick_sum, i, j, k, l
	INTEGER count,M,NSTACK
        PARAMETER(M=7, NSTACK=50000)
        INTEGER q_a,q_b,ir,jstack,istack(NSTACK)
        REAL a, temp



c	-----------------
c       Quicksort routine
c       -----------------
	jstack = 0
        l=1
        ir=quick_sum

 92     if(ir-l.lt.M) then
          do j=l+1, ir
            a=quick_list(j)
            do i=j-1,l,-1
              if(quick_list(i).le.a) goto 93
              quick_list(i+1)=quick_list(i)
            end do
            i=l-1
 93         quick_list(i+1)=a
          end do
          if(jstack.eq.0) goto 91
          ir=istack(jstack)
          l=istack(jstack-1)
          jstack=jstack-2
        else
          k=(l+ir)/2
          temp=quick_list(k)
          quick_list(k)=quick_list(l+1)
          quick_list(l+1)=temp
          if(quick_list(l).gt.quick_list(ir))then
            temp=quick_list(l)
            quick_list(l)=quick_list(ir)
            quick_list(ir)=temp
          endif
          if(quick_list(l+1).gt.quick_list(ir))then
            temp=quick_list(l+1)
            quick_list(l+1)=quick_list(ir)
            quick_list(ir)=temp
          endif
          if(quick_list(l).gt.quick_list(l+1))then
            temp=quick_list(l)
            quick_list(l)=quick_list(l+1)
            quick_list(l+1)=temp
          endif
          i=l+1
          j=ir
          a=quick_list(l+1)
 94       continue
          i=i+1
          if(quick_list(i).lt.a)goto 94
 95       continue
          j=j-1
          if(quick_list(j).gt.a)goto 95
          if(j.lt.i)goto 96
          temp=quick_list(i)
          quick_list(i)=quick_list(j)
          quick_list(j)=temp
          goto 94
 96       quick_list(l+1)=quick_list(j)
          quick_list(j)=a
          jstack=jstack+2
          if(jstack.gt.NSTACK)pause 'NSTACK SMALL'
          if(ir-i+1.ge.j-1) then
            istack(jstack)=ir
            istack(jstack-1)=i
            ir=j-1
          else
            istack(jstack)=j-1
            istack(jstack-1)=l
            l=i
          endif
        endif

        goto 92



c       -----------------------------
c	Remove any duplicate elements
c       -----------------------------
  91    j=1
        do i=2, quick_sum
          if(quick_list(i).ne.quick_list(i-1)) then
            j = j + 1
            quick_list(j) = quick_list(i)
          end if
        end do
        quick_sum = j



        return
        end


c---------------------------------------------------------------------------
        subroutine COORDINATION_CHA

        include 'rmcen.h'

c       -----------------------------------------------------------
c  	NN ENERGY AFFECTED LISTING ROUTINE FOR SPEED
c	Routine determines the atomic lists for atoms energetically
c	affected by the move of ichosen.  New quantities are then
c	calculated only for the affected atoms.
c       -----------------------------------------------------------

        integer i, j
	integer sp2_old, sp2_new
	integer sp3_old, sp3_new
	integer sp2_change, sp3_change, it, it1
	integer nn_1st_sum, nn_1st_list(1000)
        integer nn_2nd_sum, nn_2nd_list(10000)
	integer nn_3rd_sum, nn_3rd_list(50000)

        real xl2inv, yl2inv, zl2inv
	real xu, yu, zu, rsq, rdist
 	real frac, recip, expz


c	-----------------------------------------------
c 	LOOP OVER NN LIST OF NEW AND OLD POS OF ICHOSEN
c 	-----------------------------------------------
        en_ch_sum = 0

        do i = 1, newnn
          it = newlist(i)
          en_ch_sum = en_ch_sum + 1
	  en_ch_list(en_ch_sum) = it
        end do

        do i = 1, ncord(ichosen)
	  it = nnlist(ichosen,i)
	  en_ch_sum = en_ch_sum + 1
	  en_ch_list(en_ch_sum) = it
        end do


c	--------------------------------
c	SORT en_ch_list FOR THE 1st TIME
c	--------------------------------
        call QUICKSORT(en_ch_list, en_ch_sum)


c 	------------------------
c  	COPY 1ST NN TO NEW ARRAY
c 	------------------------
	nn_1st_sum = en_ch_sum
        do i = 1, en_ch_sum
	  it = en_ch_list(i)
	  nn_1st_list(i) = it
        end do


c       -------------------------------
c	LOOP OVER 2ND NN OF 1ST NN LIST
c	-------------------------------
        nn_2nd_sum = 0
        do i = 1, nn_1st_sum
          it = nn_1st_list(i)
	  do j = 1, ncord(it)
	    it1 = nnlist(it,j)

	    nn_2nd_sum = nn_2nd_sum + 1
	    nn_2nd_list(nn_2nd_sum) = it1
	    en_ch_sum = en_ch_sum + 1
	    en_ch_list(en_ch_sum) = it1
	  end do
        end do


c	--------------
c 	ADD IN ICHOSEN
c 	--------------
	en_ch_sum = en_ch_sum + 1
	en_ch_list(en_ch_sum) = ichosen



c	--------------------------------
c	SORT en_ch_list FOR THE 2nd TIME
c	--------------------------------
	call QUICKSORT(en_ch_list, en_ch_sum)




c	----------------------------------------------
c       EDIP carbon requires more neighbor information
c	EDIP Silicon and SW potentials only requires
c	the above nn information
c       ----------------------------------------------
	if(edip_type.eq.0) then

	  continue

	else

          en_to_sum = en_ch_sum

	  do i=1, en_ch_sum
	    en_to_list(i) = en_ch_list(i)
	  end do

	  nn_1st_sum = nn_1st_sum + 1
          nn_1st_list(nn_1st_sum) = ichosen
	  en_ha_sum = nn_1st_sum
	  en_ch_sum = nn_1st_sum

	  do i=1, nn_1st_sum
	    en_ha_list(i) = nn_1st_list(i)
	    en_ch_list(i) = nn_1st_list(i)
	  end do

	  goto 54321

	end if


c	----------------
c	SORT 2nd NN LIST
c	----------------
	call QUICKSORT(nn_2nd_list, nn_2nd_sum)




c	-----------------------------
c	COPY en_ch_list TO en_ha_list
c 	-----------------------------
	en_ha_sum = en_ch_sum
        do i = 1, en_ch_sum
	  it = en_ch_list(i)
	  en_ha_list(i) = it
        end do



c	-------------------------------
c 	LOOP OVER 3RD NN OF 2ND NN LIST
c 	-------------------------------
         nn_3rd_sum = 0
         do i = 1, nn_2nd_sum
	   it = nn_2nd_list(i)
	   do j = 1, ncord(it)
	     it1 = nnlist(it,j)
	     if(it1.ne.ichosen) then

	       nn_3rd_sum = nn_3rd_sum + 1
	       nn_3rd_list(nn_3rd_sum) = it1
	       en_ha_sum = en_ha_sum + 1
	       en_ha_list(en_ha_sum) = it1

	     end if
	   end do
         end do


c	---------------
c	SORT en_ha_list
c	---------------
        call QUICKSORT(en_ha_list, en_ha_sum)



c 	----------------
c 	SORT 3rd NN LIST
c 	----------------
        call QUICKSORT(nn_3rd_list, nn_3rd_sum)



c       -----------------------------
c	COPY en_ha_list TO en_to_list
c	-----------------------------
	en_to_sum = en_ha_sum
        do i = 1, en_ha_sum
	  it = en_ha_list(i)
	  en_to_list(i) = it
        end do



c	-------------------------------
c	LOOP OVER 4TH NN OF 3RD NN LIST
c	-------------------------------
        do i = 1, nn_3rd_sum
	  it = nn_3rd_list(i)
	  do j = 1, ncord(it)
	    it1 = nnlist(it,j)
	    if(it1.ne.ichosen) then

	      en_to_sum = en_to_sum + 1
	      en_to_list(en_to_sum) = it1

   	    end if
	  end do
        end do



c	---------------
c 	SORT en_to_list
c 	---------------
	call QUICKSORT(en_to_list, en_to_sum)




c	--------------------------------------------------------
c	Atoms that need recalculation of energy at in en_ch_list
c	and all the nn's are contained in en_to_list.
c       --------------------------------------------------------

c	---------------------------------
c	DETERMINE ALL REQUIRED QUANTITIES
c	---------------------------------



54321	xl2inv = 1/xl2
	yl2inv = 1/yl2
	zl2inv = 1/zl2


        do i = 1, en_ha_sum
	  it = en_ha_list(i)
	  avg_newcord(it) = 0.0
	  num(it) = 0
          num_b(it) = 0
	  do j = 1, en_to_sum
	    it1 = en_to_list(j)


	    if(it.ne.it1) then
	      if(it.eq.ichosen) then
	        xu = xc(it1) - xnewi
	        yu = yc(it1) - ynewi
	        zu = zc(it1) - znewi
	      else if(it1.eq.ichosen) then
	        xu = xnewi - xc(it)
	        yu = ynewi - yc(it)
	        zu = znewi - zc(it)
	      else
	        xu = xc(it1) - xc(it)
	        yu = yc(it1) - yc(it)
	        zu = zc(it1) - zc(it)
	      end if

	      xu = xu - (int(xu*xl2inv)*xl)
	      yu = yu - (int(yu*yl2inv)*yl)
	      zu = zu - (int(zu*zl2inv)*zl)

	      rsq = xu*xu + yu*yu + zu*zu
	      rdist = sqrt(rsq)

	      if(rdist.le.radcordn) then
	        num_b(it) = num_b(it) + 1
                near_b(it,num_b(it)) = it1
	      end if


	      if(rdist.le.redip) then
	        num(it) = num(it) + 1
	        near(it,num(it)) = it1

	        dr(it,num(it)) = rdist
	        dxdr(it,num(it)) =  xu/rdist
	        dydr(it,num(it)) =  yu/rdist
	        dzdr(it,num(it)) =  zu/rdist


	        if(edip_type.eq.0) then
	    	  if(rdist.gt.C_high-0.001) then
                    avg_newcord(it) = avg_newcord(it) + 0.0
                  elseif(rdist.lt.C_low+0.001) then
                    avg_newcord(it) = avg_newcord(it) + 1.0
                  else
                    frac=(rdist-C_low)/(C_high-C_low)
                    recip= 1.0/(1.0-frac**-3)
                    expz= exp(C_alpha*recip)
                    avg_newcord(it) = avg_newcord(it) + expz
                  end if
                end if

                if(edip_type.eq.1) then
                  if(rdist.gt.S_a2-0.001) then
                    avg_newcord(it) = avg_newcord(it) + 0.0
                  elseif(rdist.lt.S_C+0.001) then
                    avg_newcord(it) = avg_newcord(it) + 1.0
                  else
                    frac=(rdist-S_C)/(S_a2-S_C)
                    recip= 1.0/(1.0-frac**-3)
                    expz= exp(S_alpha*recip)
                    avg_newcord(it) = avg_newcord(it) + expz
                  end if
                end if

	      end if
            end if
	  end do
        end do



c	---------------------------------------------------
c	Calculate new coordination number of affected atoms
c	---------------------------------------------------
	nm_affected_atoms = 0

	do i = 1, en_ha_sum
	  it = en_ha_list(i)
	  nm_affected_atoms = nm_affected_atoms  + 1
	  list_affected_atoms(nm_affected_atoms) = it

	  new_coordn_affected(nm_affected_atoms)
     :             = num_b(it)

        end do


	sp2_old = 0
	sp3_old = 0
	sp2_new = 0
	sp3_new = 0


	do i=1, nm_affected_atoms


c	==================================
c	Calculate old sp2 and sp3 fraction
c	==================================
	  j = list_affected_atoms(i)


	  if(ncord_b(j).eq.3) then
	    sp2_old = sp2_old + 1
	  else if (ncord_b(j).eq.4) then
	    sp3_old = sp3_old + 1
	  endif


c	==================================
c       Calculate new sp2 and sp3 fraction
c       ==================================
	  if(num_b(j).eq.3) then
  	    sp2_new = sp2_new + 1
          else if (num_b(j).eq.4) then
            sp3_new = sp3_new + 1
          end if
 	end do

	sp2_change = sp2_new - sp2_old
	sp3_change = sp3_new - sp3_old

        new_sum_sp2 = old_sum_sp2 + sp2_change
        new_sum_sp3 = old_sum_sp3 + sp3_change

	return
	end



c-----------------------------------------------------------------------------
	subroutine COORDINATION_CHB

	include 'rmcen.h'

c       -------------------------------------------------------
c	NON NN EFFECTED LISTING ROUTINE - SLOWER FOR LARGE nmol
c       -------------------------------------------------------

	integer i,j, loop
	real xposi, yposi, zposi, xposj, yposj, zposj
	real xu, yu, zu
	real rsq, rdist
	real frac, recip, expz
	integer sp2_old, sp2_new
        integer sp3_old, sp3_new
        integer sp2_change, sp3_change




	en_ha_sum = nmol
	en_to_sum = nmol
        en_ch_sum = nmol

	do i=1,nmol
          num(i) = 0.0
	  num_b(i) = 0.0
          avg_newcord(i) = 0.0
	end do


	do i=1,nmol
	  if(i.eq.ichosen) then
	    xposi = xnewi
	    yposi = ynewi
            zposi = znewi
	  else
	    xposi = xc(i)
	    yposi = yc(i)
	    zposi = zc(i)
	  end if

	  do j=(i+1),nmol
	    if(j.eq.ichosen) then
	      xposj = xnewi
	      yposj = ynewi
	      zposj = znewi
	    else
	      xposj = xc(j)
	      yposj = yc(j)
              zposj = zc(j)
	    end if

	    xu = xposj - xposi
	    yu = yposj - yposi
	    zu = zposj - zposi

	    xu = xu - (int(xu/xl2)*xl)
	    yu = yu - (int(yu/yl2)*yl)
	    zu = zu - (int(zu/zl2)*zl)

	    rsq = xu*xu + yu*yu + zu*zu
	    rdist = sqrt(rsq)


	    if(rdist.le.radcordn) then
	      num_b(i) = num_b(i) + 1
	      near_b(i,num_b(i)) = j
	      num_b(j) = num_b(j) + 1
	      near_b(j,num_b(j)) = i
            end if

	    if(rdist.le.redip) then
	      num(i) = num(i) + 1
	      near(i,num(i)) = j
	      num(j) = num(j) + 1
	      near(j,num(j)) = i

	      dr(i,num(i))= rdist
              dr(j,num(j))= rdist

              dxdr(i,num(i)) = -xu/rdist
              dxdr(j,num(j)) =  xu/rdist
              dydr(i,num(i)) = -yu/rdist
              dydr(j,num(j)) =  yu/rdist
              dzdr(i,num(i)) = -zu/rdist
              dzdr(j,num(j)) =  zu/rdist

	      if(edip_type.eq.0) then
                if(rdist.gt.C_high-0.001) then
                  avg_newcord(i) = avg_newcord(i) + 0.0
                  avg_newcord(j) = avg_newcord(j) + 0.0
                elseif(rdist.lt.C_low+0.001) then
                  avg_newcord(i) = avg_newcord(i) + 1.0
                  avg_newcord(j) = avg_newcord(j) + 1.0
                else
                  frac=(rdist-C_low)/(C_high-C_low)
                  recip= 1.0/(1.0-frac**-3)
                  expz= exp(C_alpha*recip)
                  avg_newcord(i) = avg_newcord(i) + expz
                  avg_newcord(j) = avg_newcord(j) + expz
                end if
              end if

              if(edip_type.eq.1) then
                if(rdist.gt.S_a2-0.001) then
                  avg_newcord(i) = avg_newcord(i) + 0.0
                  avg_newcord(j) = avg_newcord(j) + 0.0
                elseif(rdist.lt.S_C+0.001) then
                  avg_newcord(i) = avg_newcord(i) + 1.0
                  avg_newcord(j) = avg_newcord(j) + 1.0
                else
                  frac=(rdist-S_C)/(S_a2-S_C)
                  recip= 1.0/(1.0-frac**-3)
                  expz= exp(S_alpha*recip)
                  avg_newcord(i) = avg_newcord(i) + expz
                  avg_newcord(j) = avg_newcord(j) + expz
                end if
              end if

	    end if
	  end do
	end do



c	---------------------------------------------------
c       Calculate new coordination number of affected atoms
c       ---------------------------------------------------
	nm_affected_atoms = 0

        do loop = 1, nmol
          nm_affected_atoms = nm_affected_atoms  + 1
          list_affected_atoms(nm_affected_atoms) = loop
          en_ch_list(nm_affected_atoms) = loop
          en_ha_list(nm_affected_atoms) = loop

          new_coordn_affected(nm_affected_atoms)
     :             = num_b(loop)

        end do


        sp2_old = 0
        sp3_old = 0
        sp2_new = 0
        sp3_new = 0


        do loop=1, nm_affected_atoms

c	==================================
c       Calculate old sp2 and sp3 fraction
c       ==================================
          j = list_affected_atoms(loop)

	  if(ncord_b(j).eq.3) then
            sp2_old = sp2_old + 1
          else if (ncord_b(j).eq.4) then
            sp3_old = sp3_old + 1
          endif


c	==================================
c       Calculate new sp2 and sp3 fraction
c       ==================================
	  if(num_b(j).eq.3) then
            sp2_new = sp2_new + 1
          else if (num_b(j).eq.4) then
            sp3_new = sp3_new + 1
          end if
	end do

        sp2_change = sp2_new - sp2_old
        sp3_change = sp3_new - sp3_old

        new_sum_sp2 = old_sum_sp2 + sp2_change
        new_sum_sp3 = old_sum_sp3 + sp3_change


	return
	end





c-----------------------------------------------------------------------------
	subroutine MCARLOSQ

        include 'rmcen.h'


	real xnewtt, frmcnew
	real fracsp3,xsp3, fsp3_new

	integer numsp3, nsp3step, l, nq, m, mq, i
	integer icordnew, n
	real cex, dex, ran2, deltu
	real sqolderr, sqnewerr, xoq, xnq
	real grolderr, grnewerr, grxo, grxn
	real temp1, temp2, temp3, temp4, temp5, temp6, temp7, temp8

c       --------------------------------------------------------
c       Subroutine calculates the difference between old and new
c       errors.  Acceptance condition same as that used
c       for normal Metropolis Monte Carlo algorithm
c       --------------------------------------------------------


c       -----------------
c	Zero total errors
c       -----------------
        xoldtt = 0.0
        xnewtt = 0.0




c	-----------------------
c       COORDINATION CONSTRAINT
c       -----------------------
        numsp3 = 4
        fracsp3 = 1 - frcordn


c	============
c	sp2 fraction
c	============
        frmcnew = real(new_sum_sp2)/nmol

        xnewcord=((frmcnew-frcordn)**2)/(wfcordn**2)


c	============
c	sp3 fraction
c	============
        fsp3_new = real(new_sum_sp3)/nmol


c	=========================
c	Add in coordination error
c	=========================
	if(sp_option) then
          xoldtt = xoldtt + xoldcord
          xnewtt = xnewtt + xnewcord
	endif



c	-------------
c       SQ CONSTRAINT
c       -------------
	if(sq_option) then


c	==========================
c	Zero old and new sq errors
c       ==========================
	  xoldsq = 0.0
	  xnewsq = 0.0


c       ===========================
c	Calculate old and new error
c       ===========================

	  do nq=1,nptsexpt
	    sqolderr = sqold(nq)-sqexpt(nq)
	    sqnewerr = sqnew(nq)-sqexpt(nq)

	    xoq = (sqolderr**2)/(sqerr(nq)**2)
	    xnq = (sqnewerr**2)/(sqerr(nq)**2)

	    xoldsq = xoldsq+xoq
	    xnewsq = xnewsq+xnq
  	  end do

	  sq_change = xnewsq - xoldsq




c	===============
c	Add in sq error
c	===============
	  xoldtt = xoldtt + xoldsq
	  xnewtt = xnewtt + xnewsq

	endif




c	-------------
c       GR CONSTRAINT
c       -------------
	if(gr_option) then


c	==========================
c	Zero old and new gr errors
c       ==========================
	  xoldgr = 0.0
	  xnewgr = 0.0


c       ===========================
c	Calculate old and new error
c       ===========================
	  do n=1, nptsgr_expt
            grolderr = grold(n)-grexpt(n)
            grnewerr = grnew(n)-grexpt(n)

            grxo = (grolderr**2)/(gr_error**2)
            grxn = (grnewerr**2)/(gr_error**2)

            xoldgr = xoldgr+ grxo
            xnewgr = xnewgr+ grxn

  	  end do


	  gr_change = xnewgr - xoldgr


c	===============
c	Add in sq error
c	===============
	  xoldtt = xoldtt + xoldgr
	  xnewtt = xnewtt + xnewgr

	endif









c	-----------------
c       ENERGY CONSTRAINT
c       -----------------

c	================
c       Calculate energy
c       ================
        call ENERGY_CALC


c	=============
c       Add in energy
c       =============
	if(en_option) then
          xoldtt = xoldtt + wf_energy*(old_energy_total)
          xnewtt = xnewtt + wf_energy*(new_energy_total)
	endif

	energy_change = wf_energy*(new_energy_total
     :                               - old_energy_total)



	sp_change = (xnewcord-xoldcord)

	total_cordn_error = xoldcord
	total_sq_error = xoldsq
	total_gr_error = xoldgr




c	--------------------------------------------------------
c       Acceptance Condition
c
c
c       Decide whether to accept or reject new configuration
c
c       check to see if S(q) for new configuration  is > ,
c       = or < S(q) for the previous configuration
c
c       if X neW < X OlD or = X OlD OlD then accEPT
c
c       Otherwise only accept with a probability proportional
c       to  exp(-(xnewtt-xoldtt)/2).
c       --------------------------------------------------------


	if(xnewtt.lt.xoldtt)   go to 8
	deltu = xoldtt-xnewtt
	cex = exp(deltu/2.0)
	dex=RAN2(iseed)

	if(cex.lt.dex) go to 20

    8   continue






c       ---------------------------------------------------
c       mvsacpt is counter for the number of accepted moves
c
c       mvaptflg  =  -1 if move accepted
c       mvaptflg  =  +1 if move rejected
c       ---------------------------------------------------
	mvaptflg = -1
	mvsacpt = mvsacpt+1


c	-------------------------------------------------------
c       Input new position of particle ichosen if move accepted
c       -------------------------------------------------------
	xc(ichosen) = xnewi
	yc(ichosen) = ynewi
	zc(ichosen) = znewi


c	-------------------------------------------
c       Update nn(r) for g(r) and sqold(q) for s(q)
c       -------------------------------------------
	if(gr_option.or.sq_option) then

	  call UPDATE_GR
	endif


	if(sq_option) then
	  do i=1,nptsexpt
	    sqold(i) = sqnew(i)
          end do
	endif



c	------------------
c	Update total error
c	------------------
        xoldtt = xnewtt


c	----------------------------------------
c	Update coordination numbers and nn lists
c	----------------------------------------
	call UPDATE_NN_DATA(frmcnew, fsp3_new)


c	-------------
c       Update energy
c       -------------
	call UPDATE_ENERGY


  20    continue

	return
	end




c---------------------------------------------------------------------------
        subroutine UPDATE_GR

        include 'rmcen.h'


        integer i
        real r



        do i=1,nptsgr
          nn(i) = nn(i) + nnch(i)
   	end do


	do i=1, nptsgr
	  grold(i) = grnew(i)
          if(nstage.eq.2) then
            grfinal(i) = grfinal(i) + grold(i)
          end if
  	end do


	if(nstage.eq.2) then
          grcounter = grcounter + 1
        end if



	return
	end





c---------------------------------------------------------------------------
        subroutine UPDATE_ENERGY

        include 'rmcen.h'


	integer i, j

c	-------------
c       Update energy
c       -------------
        old_energy_total = new_energy_total

        do i=1, nm_modified
          j = list_modified(i)
          energy_atom(j) = energy_modified(i)
  	end do

	return
	end






c----------------------------------------------------------------------------
        subroutine energy_calc

        include 'rmcen.h'

	integer i, jj1, kk1
	real energy_old, energy_new
	real energy_sum
	real temp2, temp3, temp4, temp5,temp6

	real T2B, T3B, RCUT, ONE_THIRD
	real rhoij, cos_x_ij, cos_y_ij, cos_z_ij
	real one_o_a, expo, gam_o_a_ij, exp_gam_ij
	real r_to_minusp, term1, rik, rhoik
	real cos_x_ik, cos_y_ik, cos_z_ik, one_o_a_ik
	real gam_o_a_ik, fact, cos_jik, cos_p_1o3
        real A_EPS

	energy_old = 0.0
        energy_new = 0.0
        nm_modified= 0.0

	if(edip_type.eq.0) then
	  call EDIP_2_CUTOFF


	  do i=1, en_ch_sum
	    ta = en_ch_list(i)

	    energy_sum = 0.0

	    energy_old = energy_old + energy_atom(ta)
	    nm_modified = nm_modified + 1
            list_modified(nm_modified) = ta

	    zz(ta) = avg_newcord(ta)

            call COORD_2_TERMS


	    C_a12 = C_a1 + C_a2*zz(ta)
	    C_tau = 1.0 - zz(ta)/12.0 * (1.0 + tanh(C_tau1+C_tau2*zz(ta)))


c       =============
c       Two Body Term
c       =============
	      do jj1=1, num(ta)


	        if(dr(ta,jj1).lt.C_a12-0.001) then

	          rij = dr(ta,jj1)
	          bond = exp(-C_beta*zz(ta)*zz(ta))
     
          energy_sum=energy_sum +C_aa*(C_bb/rij**4-bond)
     :                     *exp(C_sigma/(rij-C_a12))



c	===============
c	Three Body Term
c	===============
                  do kk1 = jj1+1, num(ta)

                    if(dr(ta,kk1).lt.C_a12-0.001) then



	   cosi = dxdr(ta,jj1)*dxdr(ta,kk1)+dydr(ta,jj1)*dydr(ta,kk1)
     :          +dzdr(ta,jj1)*dzdr(ta,kk1)


	 arg12= C_gamma/(dr(ta,jj1)-C_a12) + C_gamma/(dr(ta,kk1)-C_a12)
         zexpgam=exp(arg12-C_xmu*(zz(ta)-4.0)*(zz(ta)-3.0-0.069/C_xmu))
	 theta = C_xlam/C_qq*(1.0-exp(-C_qq*(cosi+C_tau)**2))


	   energy_sum = energy_sum + zexpgam*theta


                    end if
 	          end do
  	        end if
	      end do



	    energy_modified(nm_modified)=energy_sum
            energy_new = energy_new + energy_sum

 	  end do

        end if






	if(edip_type.eq.1) then


          do i=1, en_ch_sum
            ta = en_ch_list(i)

            energy_sum = 0.0


            energy_old = energy_old + energy_atom(ta)
            nm_modified = nm_modified + 1
            list_modified(nm_modified) = ta

            zz(ta) = avg_newcord(ta)

            S_tau=S_u1+S_u2*(S_u3*exp(-S_u4*zz(ta))-exp(-2*S_u4*zz(ta)))
            S_que=S_q0*exp(-S_mu*zz(ta))



c	=============
c       Two Body Term
c       =============
            do jj1=1, num(ta)


              if(dr(ta,jj1).lt.S_a2-0.001) then

                rij = dr(ta,jj1)
                bond = exp(-S_beta*zz(ta)*zz(ta))
     
     
        energy_sum=energy_sum+S_a1*(((S_B/rij)**S_p)-bond)
     :        *exp(S_sigma/(rij-S_a2))



c	===============
c       Three Body Term
c       ===============
                do kk1 = jj1+1, num(ta)

                  if(dr(ta,kk1).lt.S_a2-0.001) then

           cosi = dxdr(ta,jj1)*dxdr(ta,kk1)+dydr(ta,jj1)*dydr(ta,kk1)
     :          +dzdr(ta,jj1)*dzdr(ta,kk1)



	   arg12 = S_gamma/(dr(ta,jj1)-S_a2)+S_gamma/(dr(ta,kk1)-S_a2)
           S_term1 = (1-exp(-S_que*(cosi+S_tau)**2))
           S_term2 = S_n*S_que*(cosi+S_tau)**2
           S_term3 = S_lambda*(S_term1+S_term2)*exp(arg12)


           energy_sum = energy_sum + S_term3



                  end if
                end do
              end if
            end do


          energy_modified(nm_modified)=energy_sum
          energy_new = energy_new + energy_sum

          end do

	end if




	if(edip_type.eq.2.or.edip_type.eq.3) then


	  RCUT = (W_alpha * W_sigma)
	  ONE_THIRD = (1.0/ 3.0)
	  A_EPS = (W_A * W_eta)


	  do i=1, en_ch_sum
            ta = en_ch_list(i)

            T2B = 0.0
	    T3B = 0.0

            energy_old = energy_old + energy_atom(ta)
            nm_modified = nm_modified + 1
            list_modified(nm_modified) = ta


c	=============
c       Two Body Term
c       =============
            do jj1=1, num(ta)

              rij = dr(ta,jj1)

              if(rij.lt.RCUT) then

                rhoij=rij/W_sigma


	        cos_x_ij=dxdr(ta,jj1)
                cos_y_ij=dydr(ta,jj1)
                cos_z_ij=dzdr(ta,jj1)

                one_o_a =1.0/(rhoij-W_alpha)
                expo=exp(one_o_a)
                gam_o_a_ij=W_gamma*one_o_a
                exp_gam_ij=exp(gam_o_a_ij)
                r_to_minusp= rhoij**(-1*W_p)

                term1=A_EPS*(W_B*r_to_minusp-1.0)*expo

                t2B = t2B +term1*0.5




c      Three Body Term
c      ---------------

          do kk1 = jj1+1, num(ta)

            rik = dr(ta,kk1)

            if(rik.lt.RCUT) then

	      rhoik=rik/W_sigma
              cos_x_ik=dxdr(ta,kk1)
              cos_y_ik=dydr(ta,kk1)
              cos_z_ik=dzdr(ta,kk1)

              one_o_a_ik=1.0/(rhoik-W_alpha)
              gam_o_a_ik=W_gamma*one_o_a_ik
              fact = W_eta*W_lambda*exp(gam_o_a_ik)*exp_gam_ij

	      cos_jik = (cos_x_ij*cos_x_ik)+(cos_y_ij
     :      * cos_y_ik) + (cos_z_ij*cos_z_ik)

              cos_p_1o3=cos_jik+ONE_THIRD

              T3B = T3B +fact*cos_p_1o3*cos_p_1o3

            end if

	  end do
	  end if
        end do

        energy_modified(nm_modified)= T2B + T3B
        energy_new = energy_new + (T2B+T3B)


        end do

        end if




c      Calculate new energy total
c      --------------------------

        new_energy_total = old_energy_total - energy_old
     :             + energy_new




        return
        end






c----------------------------------------------------------------------------
	subroutine EDIP_2_CUTOFF

	include 'rmcen.h'

	integer loop, jj, it
	real frac, recip, expf, arg



c	-------------------------
c	Basic z with p(r) cutoffs
c	-------------------------
	do loop=1, en_ha_sum
          it = en_ha_list(loop)
	  if(avg_newcord(it).lt.4.0) then
	    do jj=1, num(it)
	      rij=dr(it,jj)
	      if(rij.gt.C_high_p-0.001) then
	        f(it,jj)=0.0

 	      elseif(rij.lt.C_low_p+0.001) then
	        f(it,jj)=1.0

	      else
	        frac=(rij-C_low_p)/(C_high_p-C_low_p)
	        recip=1.0/(1.0-frac**-3)
	        expf= exp(C_alpha*recip)

	        f(it,jj)= expf


	      endif
	    end do
          end if
        end do


c	----------------------------------
c	Determine Pi for sp1 and sp2 atoms
c	----------------------------------
	do loop=1, en_ha_sum
	  it = en_ha_list(loop)
 	  if(avg_newcord(it).lt.3.0) then
	    g(it) = 1.0
	  elseif (avg_newcord(it).gt.4.0) then
	    g(it) = 0.0
	  else
	    arg = avg_newcord(it) -3.0
	    g(it) = (arg*arg - 1.0)**2
	  end if
	end do



c	---------------------------
c       Determine Pi3 for sp2 atoms
c	---------------------------
	do loop=1, en_ha_sum
	  it = en_ha_list(loop)
	  if((avg_newcord(it).lt.2.0).or.(avg_newcord(it).gt.4.0)) then
	    g3(it) = 0.0
	  else
	    arg = avg_newcord(it) -3.0
	    g3(it)= (arg*arg -1.0)**2
	  end if
	end do


c	--------------------------
c	Determine Pi2 for sp atoms
c	--------------------------
	do loop=1,en_ha_sum
	  it = en_ha_list(loop)
	  if((avg_newcord(it).lt.1.0).or.(avg_newcord(it).gt.3.0)) then
	    g2(it)=0.0
  	  else
	    arg = avg_newcord(it)-2.0
	    g2(it)= (arg*arg -1.0)**2
	  end if
	end do



	return
	end





c----------------------------------------------------------------------------
        subroutine COORD_2_TERMS

        include 'rmcen.h'


        call DIHEDRAL_2_TERM
        call REPULSION_2_TERM
        call LINEAR_2_TERM


	return
        end



c-----------------------------------------------------------------------------
	subroutine LINEAR_2_TERM

	include 'rmcen.h'
	integer iii, j, jj, kk, k1, k2
	real rx(2,3), rr(2), ff(2), cc, gg, ff2

	if(avg_newcord(ta).gt.3.0) return

	do jj=1, num(ta)
	j=near(ta,jj)
	rij=dr(ta,jj)
	if ((avg_newcord(j).lt.4.0).and.(rij.gt.C_low_p).and.(rij.lt.c0)) then

	  do kk=1, num(ta)
	  if ((kk.ne.jj).and.(dr(ta,kk).lt.C_high_p)) then

	  rx(1,1) = dxdr(ta,jj)
	  rx(2,1) = dxdr(ta,kk)
	  rx(1,2) = dydr(ta,jj)
	  rx(2,2) = dydr(ta,kk)
	  rx(1,3) = dzdr(ta,jj)
	  rx(2,3) = dzdr(ta,kk)

	  rr(1) = dr(ta,jj)
	  rr(2) = dr(ta,kk)
	  cc = rr(1) - c0


	  ff(1) = (1.0 - f(ta,jj)) * cc * cc
	  ff(2) =        f(ta,kk)
	  ff2 = ff(1) * ff(2)

	  gg = g2(ta) * g(j)

	  do k1=1,2
	     k2= 3-k1

	  dot = 0.0
	  dot=rx(k1,1)*rx(k2,1)+rx(k1,2)*rx(k2,2)+rx(k1,3)*rx(k2,3)

	  end do

          zz(ta) = zz(ta) + zrep2 * gg * (1.0-dot*dot) * ff2

        end if
        end do

        end if
        end do



        return
        end




c-----------------------------------------------------------------------------
	subroutine REPULSION_2_TERM

	include 'rmcen.h'
	integer iii, j, jj, kk, mm, k1, k2, k3
        real  xk(3), rx(3,3),rr(3), ff(3), cc, gg, ff123

	if(avg_newcord(ta).gt.4.0) return

	do jj = 1, num(ta)
	j=near(ta,jj)
	rij=dr(ta,jj)
	if((avg_newcord(ta).lt.4.0).and.(rij.gt.C_low_p).and.(rij.lt.c0)) then

	  do kk=1, num(ta)
	  if((kk.ne.jj).and.(dr(ta,kk).lt.C_high_p)) then

	    do mm =kk+1, num(ta)
	    if((mm.ne.jj).and.(dr(ta,mm).lt.C_high_p)) then

	    rx(1,1)=dxdr(ta,jj)
	    rx(2,1)=dxdr(ta,kk)
	    rx(3,1)=dxdr(ta,mm)
	    rx(1,2)=dydr(ta,jj)
	    rx(2,2)=dydr(ta,kk)
	    rx(3,2)=dydr(ta,mm)
	    rx(1,3)=dzdr(ta,jj)
            rx(2,3)=dzdr(ta,kk)
	    rx(3,3)=dzdr(ta,mm)

	    rr(1) = dr(ta,jj)
	    rr(2) = dr(ta,kk)
	    rr(3) = dr(ta,mm)

            cc = rr(1) - c0

	    ff(1) = (1.0-f(ta,jj))*cc*cc
	    ff(2) =      f(ta,kk)
	    ff(3) =      f(ta,mm)
	    ff123  = ff(1) * ff(2) * ff(3)

	    gg = g3(ta) * g(j)


            do k1=1,3
	      k2= mod(k1  ,3) + 1
	      k3= mod(k1+1,3) + 1

	      xk(1) = rx(k2,2)*rx(k3,3) - rx(k2,3)*rx(k3,2)
	      xk(2) = rx(k2,3)*rx(k3,1) - rx(k2,1)*rx(k3,3)
	      xk(3) = rx(k2,1)*rx(k3,2) - rx(k2,2)*rx(k3,1)

	      dot=rx(k1,1)*xk(1)+rx(k1,2)*xk(2)+rx(k1,3)*xk(3)

	    end do

            zz(ta) = zz(ta) +zrep2 * gg * dot*dot * ff123

	    end if
	    end do

	  end if
 	  end do

	end if
	end do

	return
	end




c-----------------------------------------------------------------------------
	subroutine DIHEDRAL_2_TERM

	include 'rmcen.h'
	integer iii, j, jj, kk, mm, ss, k1, k2, k3
        real xk(3), rx(3,3),rr(3), ff(3), cc, gg, ff4

	if(avg_newcord(ta).gt.4.0) return

	do jj=1, num(ta)

	j=near(ta,jj)
	if((avg_newcord(j).lt.4.0).and.(dr(ta,jj).lt.C_high_p)) then


	do kk=1, num(ta)
	if((kk.ne.jj).and.(dr(ta,kk).lt.C_high_p)) then

	  do mm=kk+1, num(ta)
	  if((mm.ne.jj).and.(dr(ta,mm).lt.C_high_p)) then

	    do ss=1, num(j)
	    if((near(j,ss).ne.ta).and.(dr(j,ss).lt.C_high_p)) then

   	    rx(1,1)=dxdr(ta,kk)
            rx(2,1)=dxdr(ta,mm)
            rx(3,1)=dxdr(j,ss)
            rx(1,2)=dydr(ta,kk)
            rx(2,2)=dydr(ta,mm)
            rx(3,2)=dydr(j,ss)
            rx(1,3)=dzdr(ta,kk)
            rx(2,3)=dzdr(ta,mm)
            rx(3,3)=dzdr(j,ss)

	    rr(1) = dr(ta,kk)
	    rr(2) = dr(ta,mm)
	    rr(3) = dr(j,ss)

	    ff(1) = f(ta,kk)
	    ff(2) = f(ta,mm)
            ff(3) = f(j,ss)


	    ff4 = ff(1) * ff(2) * ff(3) * f(ta,jj)

	    gg = g3(ta) * g3(j)

	    do k1=1,3
	      k2 = mod(k1  ,3) + 1
	      k3 = mod(k1+1,3) + 1

	      xk(1) = rx(k2,2)*rx(k3,3) - rx(k2,3)*rx(k3,2)
	      xk(2) = rx(k2,3)*rx(k3,1) - rx(k2,1)*rx(k3,3)
	      xk(3) = rx(k2,1)*rx(k3,2) - rx(k2,2)*rx(k3,1)


	      dot=rx(k1,1)*xk(1)+rx(k1,2)*xk(2)+rx(k1,3)*xk(3)

	    end do

	    zz(ta) = zz(ta) + zdih * gg * dot * dot * ff4

	  end if
	  end do
	end if
	end do
	end if
	end do
	end if
	end do


	return
	end





c-----------------------------------------------------------------------------
        subroutine UPDATE_NN_DATA(frmcnew, fsp3_new)


        include 'rmcen.h'

	integer loop, loop1, n, j, k


	real energy_sum, energy
	real frmcnew, fsp3_new
	integer countingbar

	integer i, jj,kk, it
	logical print_data


        do loop=1, en_ha_sum
	  it = en_ha_list(loop)
          ncord(it)= num(it)
	  ncord_b(it)= num_b(it)
	  do loop1 = 1, num(it)
	    nnlist(it,loop1)= near(it,loop1)
	  end do

	  do loop1 = 1, num_b(it)
	    nnlist_b(it,loop1)= near_b(it,loop1)
	  end do
	end do



c       -------------------------------------------------------
c       Update fraction of properly coordinated atoms and error
c       -------------------------------------------------------



        old_sum_sp2 = new_sum_sp2
        old_sum_sp3 = new_sum_sp3

        xoldcord  = xnewcord

        total_cordn_error = xnewcord
        total_sq_error = xnewsq
	total_gr_error = xnewgr


        numbcord  = new_sum_sp2
        ncordsp3  = new_sum_sp3

        frmc = frmcnew
        fsp3 = fsp3_new






	return
	end



c----------------------------------------------------------------------------
        subroutine GRFFT(gr,sqinp)


        include 'rmcen.h'


c	----------------------------------------------
c       Fast fourier transform of a g(r)
c
c
c       all even elements (complex) set to zero
c       and all elements from nqpts to 2nqpts-2 to zero
c       nnq is the number of pairs of complex numbers
c       in the data array
c       -----------------------------------------------


	real sqinp(1000)
	real data(20000)
	real gr(max_gr_points)


	integer nnq, ic,ir, iext, ieven, isign, m, mm, md
	integer i, j

	nnq = 2*nqpts-2


	if(mod(nnq,2).ne.0) then
	  print*,' nnq = 2*nqpts-2 MUST bE EVEN'
	  stop
	endif


	do i=1, 2*igrend-1, 2
	  ir = (i+1)/2
	  data(i)=(ir-1)*(gr(ir)-1)
    	end do


	do i=2*(nqpts+1) -1, 2*(2*nqpts-2)-1, 2
	  data(i)=0.0
    	end do


	do i = 2, 2*(2*nqpts-2), 2
	  data(i) = 0.0
    	end do


	isign = 1


	call FOUR1(data,nnq,isign)


	do i=2*(nqstart),2*(nqfinish),2
	  m  = i/2 - 1
	  mm = i/2 - nqstart + 1
	  sqinp(mm) = 1 + sqconst*data(i)/m
   	end do


	return
	end




c---------------------------------------------------------------------

	subroutine FOUR1(data,nnq,isign)

	DOUBLE PRECISION WR,WI,WPR,WPI,WTEMP,THETA
	DIMENSION DATA(2*NNQ)

	N=2*NNQ
	J=1

cfpp$ skip

	DO 11 I=1,N,2
		IF(J.GT.I) THEN
			TEMPR=DATA(J)
			TEMPI=DATA(J+1)
			DATA(J)=DATA(I)
			DATA(J+1)=DATA(I+1)
			DATA(I)=TEMPR
			DATA(I+1)=TEMPI
		 ENDIF
		 M=N/2
   1    IF((M.GE.2).AND.(J.GT.M)) THEN
		J=J-M
		M=M/2
	 GO TO 1
	 ENDIF
	 J=J+M
   11    CONTINUE

C        PRINT*,'BIT REVERSAL COMPLETED'
	MMAX=2
   2    IF  (N.GT.MMAX)  THEN
	ISTEP=2*MMAX

	THETA=6.28318530717959D0/(ISIGN*MMAX)
	WPR=-2.D0*DSIN(0.5D0*THETA)**2
	WPI=DSIN(THETA)
	WR=1.D0
	WI=0.D0
cfpp$ skip

	DO 13 M=1,MMAX,2
cfpp$ skip
		DO 12 I=M,N,ISTEP
			J=I+MMAX
			TEMPR=SNGL(WR)*DATA(J)-SNGL(WI)*DATA(J+1)
			TEMPI=SNGL(WR)*DATA(J+1)+SNGL(WI)*DATA(J)
			DATA(J)=DATA(I)-TEMPR
			DATA(J+1)=DATA(I+1)-TEMPI
			DATA(I)=DATA(I)+TEMPR
			DATA(I+1)=DATA(I+1)+TEMPI

C                        PRINT*,J,DATA(J),DATA(J+1)

   12   CONTINUE
	   WTEMP=WR
	   WR=WR*WPR-WI*WPI+WR
	   WI=WI*WPR+WTEMP*WPI+WI
   13   CONTINUE

	MMAX=ISTEP
	GO TO 2
	ENDIF
	RETURN
	END







c---------------------------------------------------------------------------
	subroutine INITIAL_CONFIG

c	--------------------------------------------------------
c       Reads in initial.xyz file and determines the cell length
c
c	Cell length is determined either by
c       * input density and nmol or
c	* input cell length
c
c       Using an input cell length ignores the system density
c 	--------------------------------------------------------

        include 'rmcen.h'

        double precision cellside,xx
        real xl_cpcell, yl_cpcell, zl_cpcell
        real rho_cp, rho_cp_mass, c4
        real xmax, ymax, zmax, xrandm, ran2
        real xposi, yposi, zposi, xu, yu, zu
        real rsq, rdist, x_c, y_c, z_c

        integer i, number_images, new_nmatoms, k,l, n,j
        integer nmatoms_car_par, ncord_test(100000)
        real scale_factor
	integer c1,c2,c3, counter


	do i = 1, 100000
	  ncord_test(i) = 0
	end do

        xmax = -10000
        ymax = -10000
        zmax = -10000



c       -----------------------------------------------
c	Set Cell mode: Use xlcell value from input file
c       -----------------------------------------------
 	if(xlcell.gt.0) then
 	  xl = xlcell
 	  yl = xlcell
 	  zl = xlcell

  	if(scrwrite.eq.1) then
	  print*,'  '
 	  print*,'- MODE: Cell length set (ignore density)'
        end if
	  write(21,11)
  11    format(/,10x,'- MODE: Cell length set (ignore density)')


 	end if

c       -------------------------------------------------
c       Set cell on density mode: Use nmol and density to
c	determine the cell length
c       -------------------------------------------------
 	if(xlcell.eq.0) then
	  xl = (real(nmol)/rho)**(0.333333333)
	  yl = (real(nmol)/rho)**(0.333333333)
	  zl = (real(nmol)/rho)**(0.333333333)

	if(scrwrite.eq.1) then
	  print*,' '
	  print*,'- MODE: Cell length from density-nmol'
	end if

	  write(21,12)
  12    format(/,10x,'- MODE: Cell length from density-nmol')

	end if


c	----------------------------------------------------------
c       Define half cell length for minimum imagining calculations
c       ----------------------------------------------------------
        xl2 = xl/2.0
        yl2 = yl/2.0
        zl2 = zl/2.0

        cellmax = xl2



c	----------------------------------------------
c       Read in atom coordinates from initial.xyz file
c       ----------------------------------------------

	if(istart.eq.1) then

	if(scrwrite.eq.1) then
	print*,'- Initial Configuration: initial.xyz'
	end if

        open(47, file = 'initial.xyz', status = 'old')

          do i = 1, nmol
            read(47,*) xc(i), yc(i), zc(i)
            if(xc(i).gt.xmax) xmax = xc(i)
            if(yc(i).gt.ymax) ymax = yc(i)
            if(zc(i).gt.zmax) zmax = zc(i)

            xx = xmax
            if(ymax.gt.xx) xx = ymax
            if(zmax.gt.xx) xx = zmax
 	  end do

  	  print*,'  '
	  print*,'- MODE: Read xyz from initial.xyz'
        end if


c	----------------------------------------------
c       Generate atomic coordinations from generator
c       ----------------------------------------------

	if(istart.eq.2) then

	if(scrwrite.eq.1) then
	print*,'- Initial Configuration: Random Generator'
	end if

        do i = 1, nmol

  60	x_c = rand() * xl
	y_c = rand() * xl
	z_c = rand() * xl


	  if(i.eq.1) then
	    xc(i) = x_c
            yc(i) = y_c
            zc(i) = z_c
	  end if

          if(i.ne.1) then

	    do j = 1, i-1
	      xu = x_c - xc(j)
	      yu = y_c - yc(j)
	      zu = z_c - zc(j)

	      xu = xu - (int(xu/xl2)*xl)
	      yu = yu - (int(yu/xl2)*xl)
	      zu = zu - (int(zu/xl2)*xl)

	      rdist = (xu*xu+yu*yu+zu*zu)

	      if(rdist.lt.(hdcore*hdcore)) then
	        goto 60
	      end if

	    end do

	    xc(i) = x_c
            yc(i) = y_c
            zc(i) = z_c

          end if
        end do


        do i = 1, nmol
            if(xc(i).gt.xmax) xmax = xc(i)
            if(yc(i).gt.ymax) ymax = yc(i)
            if(zc(i).gt.zmax) zmax = zc(i)

            xx = xmax
            if(ymax.gt.xx) xx = ymax
            if(zmax.gt.xx) xx = zmax
 	  end do
	end if

c	FIX: Initial configuration nn distance maximization



c	-------------------------------------------------------
c       Print out some initial cell values including maximum
c	atomic coordinate values, a density based on density
c	and nmol (whether used or not) and the cell dimensions
c	used in the simulation
c       --------------------------------------------------------

        if(scrwrite.eq.1) then

        print*,' '
	print*,'INITIAL STRUCTURE DIMENSIONS'
	print*,'Max atomic x value:', xmax
        print*,'Max atomic y value:', ymax
        print*,'Max atomic z value:', zmax
        print*,' '

        print*,'THEORETICAL CELL DIMENSIONS (from nmol and density)'
        print*,'xl:', (real(nmol)/rho)**(0.333333333)
        print*,'yl:', (real(nmol)/rho)**(0.333333333)
        print*,'zl:', (real(nmol)/rho)**(0.333333333)
        print*,' '

	print*,'CELL DIMENSION USED'
	print*,'xl:', xl
        print*,'yl:', xl
        print*,'zl:', xl
        print*,' '


        print*,'INPUT NMOL:', nmol
        print*,'INPUT DENSITY:', rho
        print*,'CELL DENSITY:', nmol/(xl*yl*zl)
        print*,' '

	end if

         write(21,13)
  13    format(/,10x,'Cell lengths - x,y,z:')
  	 write(21,14) xl,yl,zl
  14    format(3(f8.4,1x))






c	-------------------------------------
c       Check that no atoms fall outside cell
c	-------------------------------------
        if(xmax.gt.xl.or.ymax.gt.yl.or.zmax.gt.zl) then
          print*,'- ATOM OUT OF CELL -> Check cell parameters'
          STOP
        end if

	if(scrwrite.eq.1) then
        print*, ' '
        print*,'- Cell check SUCCESSFUL - > Atoms within cell '
        end if






c	------------------------------------------------------
c	Remove atoms randomly if nmol_remove is not equal to 0
c	------------------------------------------------------
	do i = 1, nmol_remove
	  xrandm = RAN2(iseed)
	  ichosen = nmol*xrandm
	  ichosen = ichosen+1
	  if(ichosen.gt.nmol)   ichosen = nmol
	  if(ichosen.lt.0)      ichosen = 1

	  do j = 1, nmol

	    if(j.eq.ichosen.and.ichosen.ne.nmol) then
	      xc(j)=xc(j+1)
	      yc(j)=yc(j+1)
	      zc(j)=zc(j+1)
	    end if

	    if(j.gt.ichosen.and.ichosen.ne.nmol) then
	      xc(j)=xc(j+1)
	      yc(j)=yc(j+1)
	      zc(j)=zc(j+1)
	    end if

	  end do
	  nmol = nmol - 1
	end do

	if(nmol_remove.ne.0) then
	if(scrwrite.eq.1) then
	print*,''
	print*,'- MODE: Nmol remove option'
	print*,'- No. of atoms randomly removed:',nmol_remove
	print*,'- No. of atoms after removal   :',nmol
	end if


	write(21,15)
  15    format(/,10x,'-Nmol Remove option used: nmol_remove, nmol')
  	write(21,17) nmol_remove, nmol
  17    format(3(i8,1x))

        end if




c	----------------------------------------------------
c	Remove atoms if pore_option is used using pore array
c	----------------------------------------------------
	if(pore_option.eq.1) then


c	=============================
c       Determine pore cell grid size
c	=============================
	  c4 = xl/po_res


c       =========================
c	Zero pore occupancy array
c       =========================
	  do i=1, max_res
            do j=1, max_res
              do k=1, max_res

                po_cellC(i,j,k) = 0

              end do
            end do
          end do


c	================================================
c       Read into pore occupany array from pore.xyz file
c       ================================================
	  open(49, file = 'pore.xyz', status = 'unknown')

          do i=1, pore_points
	    read(49,*) c1, c2, c3
            po_cellC(c1,c2,c3) = 1
          end do


c       =====================================================
c	Make a list of only atoms that are not in a pore grid
c	(ie. po_cellC is 0 in the grid the atoms occupy)
c       =====================================================
          counter = 0
          do i=1, nmol

            c1 = (int(xc(i)/c4))+1
            c2 = (int(yc(i)/c4))+1
            c3 = (int(zc(i)/c4))+1

            if(po_cellC(c1,c2,c3).eq.0) then
              counter = counter + 1

              xc(counter) = xc(i)
              yc(counter) = yc(i)
              zc(counter) = zc(i)

            end if
          end do

          nmol = counter



          if(scrwrite.eq.1) then
	print*,''
	print*,'- MODE: Pore Option Used'
	print*,'- Nmol after pore creation:',nmol
          end if

	write(21,16)
  16    format(/,10x,'-Pore Option Used: nmol after pore creation')
  	write(21,18) nmol
  18    format(3(i8,1x))



c	=====================
c	Remove any lone atoms
c       =====================
	  if(pore_remove.eq.1) then

            do i = 1,nmol

	      xposi = xc(i)
	      yposi = yc(i)
	      zposi = zc(i)

	      do j = (i+1),nmol

	        xu = xc(j) - xposi
	        yu = yc(j) - yposi
	        zu = zc(j) - zposi

  	        xu = xu - (int(xu/xl2)*xl)
	        yu = yu - (int(yu/yl2)*yl)
	        zu = zu - (int(zu/zl2)*zl)

	        rsq = xu*xu + yu*yu + zu*zu
                rdist = sqrt(rsq)


c	=============================
c       Calculate coordination number
c       =============================
                if(rdist.le.radcordn) then
	          ncord_test(i)=ncord_test(i)+1
                  ncord_test(j)=ncord_test(j)+1
	        end if

              end do
            end do


            counter = 0

            do i = 1, nmol

              if(ncord_test(i).gt.0) then
                counter = counter + 1
                xc(counter) = xc(i)
                yc(counter) = yc(i)
                zc(counter) = zc(i)
              end if
            end do

            nmol = counter

	    if(scrwrite.eq.1) then
            print*,'- NMOL(after lone atom removal):',nmol
	    end if

  	  end if
	end if


c	--------------------------------------------------
c	Output initial xyz cord -> startxx.xyz
c	--------------------------------------------------




  	do i=1, nmol

  	write(56,10) xc(i),yc(i),zc(i)
  10    format(3(f8.4,1x))


  	end do


        return
        end





c============================================================================
        subroutine coordn_atoms

        include 'rmcen.h'


	integer nnhist(0:20)
	real fraction_nn, average_nn
	real fraction_sp2, fraction_sp3
	character *12 nnfile

	real xposi, yposi, zposi, xu, yu, zu
	real rsq, rdist, avgcord, prob
	integer i, j

	integer ncord_dist(200), bin_min, bin_max, bin
	real del_ncord, sum



c	Zero listing arrays
c	-------------------
	do i=1, nmol
          ncord_b(i) = 0
    	end do

    	do i=1, 20
    	  nnhist(i) = 0
    	end do

    	average_nn = 0



        do i=1,nmol

          xposi = xc(i)
          yposi = yc(i)
          zposi = zc(i)

          do j=(i+1),nmol

c       minimum imaging
c       ===============

            xu = xc(j) - xposi
            yu = yc(j) - yposi
            zu = zc(j) - zposi

c       select appropriate minimum imaging conditions wrt lattice
c       ---------------------------------------------------------

            xu = xu - (int(xu/xl2)*xl)
            yu = yu - (int(yu/yl2)*yl)
            zu = zu - (int(zu/zl2)*zl)

            rsq = xu*xu + yu*yu + zu*zu
	    rdist = sqrt(rsq)

c       calculate coordination number
c       -----------------------------

            if(rdist.le.radcordn) then
              ncord_b(i)=ncord_b(i)+1
              ncord_b(j)=ncord_b(j)+1
            endif


          end do
    	end do


c	Calculate histogram
c	-------------------


	do i=1, nmol
          nnhist(ncord_b(i)) = nnhist(ncord_b(i)) + 1
	  average_nn = average_nn + ncord_b(i)
  	end do

	average_nn = average_nn/nmol


	write(21,100) average_nn
  100	format(10x,'Final Average coordination number ', f9.6)

	write(nnfile, 10) numbfile
  10    format('nncord',i2.2,'.dat')

	open(50, file = nnfile, status='unknown')


	do i=1, 10
	  fraction_nn = real(nnhist(i))/nmol
          write(50,105) i, fraction_nn
  105	  format(i2, 2x, f9.6)
 	end do


	close(50)








	return
	end


c----------------------------------------------------------------------------c


      FUNCTION RAN2(idum)

      INTEGER idum,IM1,IM2,IMM1,IA1,IA2,IQ1,IQ2,IR1,IR2,NTAB,NDIV
      REAL ran2,AM,EPS,RNMX
      PARAMETER (IM1=2147483563,IM2=2147483399,AM=1./IM1,IMM1=IM1-1,
     * IA1=40014,IA2=40692,IQ1=53668,IQ2=52774,IR1=12211,
     * IR2=3791,NTAB=32,NDIV=1+IMM1/NTAB,EPS=1.2e-7,RNMX=1.-EPS)

c Long period (? 2 \Theta 10 18 ) random number
c generator of L'Ecuyer with Bays�Durham shuffle
c and added safeguards. Returns a uniform random
c deviate between 0.0 and 1.0 (exclusive
c of the endpoint values). Call with idum a negative
c integer to initialize; thereafter, do not
c alter idum between successive deviates in a sequence.
c RNMX should approximate the largest
c floating value that is less than 1.

      INTEGER idum2,j,k,iv(NTAB),iy
      SAVE iv,iy,idum2
      DATA idum2/123456789/, iv/NTAB*0/, iy/0/
      if (idum.le.0) then
        idum=max(-idum,1)
c  Be sure to prevent idum = 0.
        idum2=idum
        do j=NTAB+8,1,-1
c Load the shuffle table (after 8 warm�ups).
          k=idum/IQ1
          idum=IA1*(idum-k*IQ1)-k*IR1
          if (idum.lt.0) idum=idum+IM1
          if (j.le.NTAB) iv(j)=idum
        enddo
        iy=iv(1)
      endif
      k=idum/IQ1
c Start here when not initializing.
      idum=IA1*(idum-k*IQ1)-k*IR1
c Compute idum=mod(IA1*idum,IM1) without over�
c flows by Schrage's method.
      if (idum.lt.0) idum=idum+IM1
      k=idum2/IQ2
      idum2=IA2*(idum2-k*IQ2)-k*IR2
c Compute idum2=mod(IA2*idum2,IM2) likewise.
      if (idum2.lt.0) idum2=idum2+IM2
      j=1+iy/NDIV
c Will be in the range 1:NTAB.
      iy=iv(j)-idum2
c Here idum is shuffled, idum and idum2 are com�
c bined to generate output.
      iv(j)=idum
      if(iy.lt.1)iy=iy+IMM1
      ran2=min(AM*iy,RNMX)
c Because users don't expect endpoint values.
      return
      END

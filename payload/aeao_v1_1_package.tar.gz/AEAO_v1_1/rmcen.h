

	implicit none

	common/nme_total/nme


        common/rmcvar/nmcstep,stepsize,mvaptflg,write,irun, scrwrite
     2,istart,ierror,mwrite,iruntype,nmol,nqpts,npre,hdcore,delq,nqstart
     2,nqfinish,stpszinp,ioptmdel,nptssq,iseed,sqerror
     2,radcordn
     4,frcordn,wfcordn,nmcordn,nptsexpt,sqexpt,sqerr,ilat
     5,nmolcell,delr,delrinv,prodel
     6,hdcoresq,nptsgr,rmax,rmaxsq,cellmax,igrstart,igrend,sqconst
     7,grnormlu,grold,grnew,grexpt,nn,ncord, grfinal
     8,cosa,cosg,sing
     8,zxtr,zytr,cosb,uky,ukz,numbcord,frmc
     9,xoldcord,avgnn,xstart,ystart,zstart
     9,mvsacpt,sqold,sqnew,sqtot,nuncell, nnch
     9,ichosen,xnewi,ynewi,znewi,move_rejected,xnewcord,xunit,yunit
     9,zunit,mpwrite,nstage,numbfile,numbacc, xoldtt
     9,sp2_sum, sp3_sum, fsp3, nnlist
     9,newnn, newlist, oldnn, oldlist
     9,nm_modified, list_modified, energy_modified
     9,old_sum_sp2, new_sum_sp2
     9,old_sum_sp3, new_sum_sp3, ncordsp3, xoldsq, xnewsq
     9,total_gr_error, xoldgr, xnewgr
     9,total_cordn_error, total_sq_error
     9,old_energy_total, new_energy_total
     9,wf_energy, energy_atom, sq_change, sp_change
     9,energy_change, wf_avgcord
     9,old_sum_avgcord, new_sum_avgcord , ac_change
     9,newnn_distance, oldnn_distance
     9,nm_affected_atoms, list_affected_atoms,new_coordn_affected
     9,nm_avgcord, new_avgcord, list_avgcord, old_avg_cordn
     9,new_avg_cordn,sq_option, sp_option, en_option, avg_option
     9,gr_option,nptsgr_expt,gr_change,gr_error,nnlist_option,fft_flag
     9,avg_ncord,xc,yc,zc,xl,yl,zl,xl2,yl2,zl2,rho, xlcell
     9,edip_type, S_u1, S_u2, S_u3, S_u4, S_a1, S_a2, S_lambda
     9,S_q0, S_alpha, S_B, S_C, S_gamma, S_mu, S_p, S_sigma
     9,S_n, S_beta, S_tau, S_que, S_term1, S_term2, S_term3

     9,W_eta, W_A, W_B, W_sigma, W_p, W_alpha, W_lambda, W_gamma

     9,po_lcell, po_res, po_cell, po_xatom, po_yatom, po_zatom
     9,po_total_old, po_total_new, po_res3, xindex_new
     9,yindex_new, zindex_new, xindex, yindex, zindex, specific
     9,wfspecific
     9,po_sxp, po_sxn, po_syp, po_syn, po_szp, po_szn
     9,po_surf, po_surface_old, po_surface_new
     9,po_cell_check, po_cellA,po_cellB,pore_option,pore_points
     9,pore_remove


     9,nmol_remove, Tsmooth_option, stage_no, grcounter


     9, C_B, C_beta, C_sigma, C_a1, C_a2
     9, tau_z,lambda_z,C_t1,C_t2,C_lambda1,C_lambda2
     9, h_theta_z, C_q, C_low_p, C_high_p
     9, C_aa, C_bb, C_xmu
     9, C_xlam, C_tau1, C_tau2, C_gamma, C_qq, C_alpha
     9, dr, dxdr, dydr, dzdr, C_a12, z, zz, C_tau, rij, bond, cosi
     9, arg12, zexpgam, theta, f, g, g2, g3, c0, dot, zrep2
     9, selector, num, near
     9, C_low, C_high, zdih, avg_newcord
     9, en_ch_sum, en_ha_sum, en_to_sum, en_ch_list

     9, en_ha_list, en_to_list, ta
     9, tempK, tempK1, tempK2, tempK3
     9, lengthstage, lengthstage1, lengthstage2
     9, redip, ncord_b, nnlist_b, num_b, near_b

     9, clock_start, po_cellC



	integer max_atoms
	parameter (max_atoms = 35000)

	integer maximum_nn
	parameter (maximum_nn = 200)

	integer max_sq_data_points
	parameter (max_sq_data_points = 1000)

	integer max_gr_points
	parameter (max_gr_points= 5000)

	integer max_res
	parameter (max_res = 100)


	real po_lcell, specific, wfspecific
	integer po_res, po_cell(max_res,max_res,max_res), po_zatom(max_atoms)
	integer po_cell_check(max_res,max_res,max_res)
	integer po_cellA(max_res,max_res,max_res)
	integer po_cellB(max_res,max_res,max_res)
	integer po_cellC(max_res,max_res,max_res)
	integer po_xatom(max_atoms), po_yatom(max_atoms)
	integer po_total_old, po_total_new, po_res3
	integer xindex_new, yindex_new, zindex_new
	integer xindex, yindex, zindex, nmol_remove
	integer po_sxp(max_res,max_res,max_res)
	integer po_sxn(max_res,max_res,max_res)
	integer po_syp(max_res,max_res,max_res)
	integer po_syn(max_res,max_res,max_res)
	integer po_szp(max_res,max_res,max_res)
	integer po_szn(max_res,max_res,max_res)
        integer po_surf(max_res,max_res,max_res)
        integer po_surface_old, po_surface_new
        integer pore_option, pore_points, pore_remove

	integer nmcstep, mvaptflg,ierror,write,irun
	integer mvsacpt, mpwrite,nstage,numbfile,numbacc
	integer stage_no, scrwrite

	real xl,yl,zl,xl2,yl2,zl2
	real xlcell

	real stepsize, stpszinp
	logical ioptmdel

	integer ichosen, grcounter, clock_start
	logical move_rejected
	real xnewi,ynewi,znewi

	integer istart, mwrite,iruntype,nmol,nqpts,npre
	real hdcore,hdcoresq
	real rho

	integer nqstart,nqfinish,nptssq,iseed
	real sqerror, delq

	real sqold(max_sq_data_points),sqnew(max_sq_data_points)
	real sqtot(max_sq_data_points)

	integer ilat, nmolcell, nuncell
	real xunit,yunit,zunit

	real radcordn,frcordn,wfcordn, frmc
	integer nmcordn, numbcord, ncordsp3


        integer ncord(max_atoms), ncord_b(max_atoms)
	real avg_ncord(max_atoms)


	integer nnlist(max_atoms,500), nnlist_b(max_atoms,500)

	integer newnn, newlist(500)
	integer oldnn, oldlist(500)

        integer nm_modified, list_modified(max_atoms)
        real energy_modified(max_atoms)


	integer  old_sum_sp2, new_sum_sp2
	integer old_sum_sp3, new_sum_sp3

	real sp2_sum, sp3_sum
	real fsp3

	real xoldcord, xnewcord
	real xoldtt
	real avgnn

	integer nptsexpt
	real sqexpt(max_sq_data_points),sqerr(max_sq_data_points)

	real xc(max_atoms),yc(max_atoms),zc(max_atoms)
	real xstart(max_atoms),ystart(max_atoms),zstart(max_atoms)


	real delr,delrinv,prodel
        real rmax,rmaxsq,cellmax

	integer nptsgr, igrstart,igrend

	real sqconst, grnormlu(max_gr_points),grnew(max_gr_points)
	real grold(max_gr_points), grfinal(max_gr_points)
	real grexpt(max_gr_points)


	integer nn(max_gr_points), nnch(max_gr_points)
	double precision nme(max_gr_points)


	real cosa,cosg,sing,zxtr,zytr,cosb,uky,ukz

	real xoldsq, xnewsq
	real xoldgr, xnewgr, total_gr_error

	real total_cordn_error, total_sq_error

        real old_energy_total,  new_energy_total
        real wf_energy, tempK, tempK1, tempK2, tempK3

        real energy_atom(max_atoms)
	real  sq_change, sp_change,energy_change

	real wf_avgcord
	real old_sum_avgcord, new_sum_avgcord, ac_change

	real newnn_distance(100)
	real oldnn_distance(100)


	integer nm_affected_atoms, list_affected_atoms(max_atoms)
        integer new_coordn_affected(max_atoms)

	integer nm_avgcord, list_avgcord(max_atoms)
	real new_avgcord(max_atoms)

	real old_avg_cordn, new_avg_cordn

	logical  sq_option, sp_option, en_option,avg_option
	logical  gr_option

	logical  nnlist_option, Tsmooth_option

	real lengthstage, lengthstage1, lengthstage2

        real gr_error, gr_change
	integer nptsgr_expt
	integer edip_type

	real redip

	real error_counter(60000)

  	integer selector, num(max_atoms)
        integer num_b(max_atoms)

 	real C_epsilon, C_B, C_beta, C_sigma, C_a1, C_a2
        real tau_z,lambda_z,C_t1,C_t2,C_lambda1,C_lambda2
        real h_theta_z, C_q
	real C_low_p, C_high_p, C_aa, C_bb, C_xmu, C_xlam
        real C_low, C_high, C_tau1, C_tau2, C_gamma
	real C_a12, C_tau, rij, bond, cosi, arg12, zexpgam, theta
	real C_qq, C_alpha, c0, zrep2, zdih
	real S_tau, S_que, S_term1, S_term2, S_term3

	real S_u1, S_u2, S_u3, S_u4, S_a1, S_a2, S_lambda, S_q0
	real S_alpha, S_B, S_C, S_gamma, S_mu, S_p, S_sigma, S_n
	real S_beta

	real W_eta, W_A, W_B, W_sigma, W_p, W_alpha
	real W_lambda, W_gamma


	real dot

	real dr(max_atoms,500), dxdr(max_atoms,500), dydr(max_atoms,500)
	real dzdr(max_atoms,500), f(max_atoms, 600), g(max_atoms)
 	real z(max_atoms),zz(max_atoms), g2(max_atoms), g3(max_atoms)
        integer near(max_atoms,1000), near_b(max_atoms,500)

        logical fft_flag

	integer  ta
	integer en_ch_sum, en_ha_sum, en_to_sum
	integer en_ch_list(60000), en_ha_list(60000), en_to_list(60000)

	real avg_newcord(max_atoms)

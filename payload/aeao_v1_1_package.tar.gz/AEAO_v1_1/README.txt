HRMC Instructions

HRMC.f - fortran 77 source code
rmcen.h - header file called in from HRMC.f
rmcen.inp - variables for simulation file

initial.xyz - initial starting structure xyz coordinate file
pore.xyz - pore grid array file if using porosity grids
grexp.dat - experimental radial distribution function
sqexp.dat - experimental structure factor 


The rmcen.inp file is setup to run the test simulation outlined in the submitted paper.
It does not use the initial.xyz or pore.xyz files but generates a random
starting structure without pores.

Simply compile via any standard f77 compiler and run the executable.
The output files generated at the end of the simulation should match
those in the 'test application output files' directory.


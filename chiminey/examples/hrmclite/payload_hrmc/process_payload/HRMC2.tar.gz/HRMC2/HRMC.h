    implicit none


	
!	2. Input File Variables
	common/var/scrwrite,istart,config_comp
	common/var/configA,configB,configC
	common/var/n_configA,n_configB,n_configC
	common/var/bond_length1,bond_length2,bond_length3
	common/var/bond_length12,bond_length13,bond_length23
	common/var/rho
	common/var/xl,yl,zl
	common/var/pbc_option
	common/var/fix_var
	common/var/npre,irun,ierror,iconfig,nqpts
	common/var/hdcore
	common/var/iseed
	common/var/pore_option
	common/var/po_res
	common/var/pot_type
	common/var/gr_option,sq_option,en_option,co_option
	common/var/vo_option,bo_option
	common/var/ring3_option
	common/var/nobond_option
	common/var/quench_option
	common/var/lengthstage
	common/var/tempK
	common/var/grerr
	common/var/sqerr
	common/var/coerr
	common/var/voerr
	common/var/boerr
	common/var/steper
	common/var/ring3er
	common/var/quenchR
	common/var/nptsgr_expt,nptssq_expt,nqstart,nqfinish
	common/var/delq
	common/var/volume
	common/var/coord_exp
	common/var/co_opt

!	3. Simulation parameters
	common/var/nmol,countA,countB,countC	
	common/var/step_restart,nmcstep
	common/var/xl2,yl2,zl2
	common/var/xl2inv,yl2inv,zl2inv
	common/var/stage_length1_t,stage_length2_t
	common/var/stage_length3_t,stage_length4_t
	common/var/tempK_drop
	common/var/step_drop
	common/var/grerr_drop
	common/var/sqerr_drop
	common/var/coerr_drop
	common/var/voerr_drop
	common/var/boerr_drop
	common/var/ring3_drop
	common/var/temper
	common/var/ring3prob
	common/var/stepsize
	common/var/mvsacpt,mvsacpt2
	common/var/stage_no,nstage
	common/var/ichosen
	common/var/move_rejected
	common/var/hdcoresq
	common/var/move_type
	common/var/newnn
	common/var/newlist
	common/var/c_lab
	common/var/select_a, select_b
	common/var/select_aold, select_bold
	common/var/fix_atom
	
!	4. Neighbor Lists	
	common/var/dr
	common/var/dxdr
	common/var/dydr 
	common/var/dzdr
	common/var/xc,yc,zc
	common/var/xnewi,ynewi,znewi
	common/var/ncord
	common/var/num	
	common/var/ncord_b
	common/var/num_b	
	common/var/nnlist
	common/var/near
	common/var/nnlist_b
	common/var/near_b
	common/var/en_ch_sum,en_ha_sum,en_to_sum
	common/var/en_ch_list,en_ha_list,en_to_list
	
!	5. Cost Functions
	common/var/gr_error,sq_error
	common/var/co_error,vo_error,bo_error
	common/var/xoldtt,xnewtt
	common/var/xoldgr,xnewgr
	common/var/xoldsq,xnewsq
	common/var/xoldco1,xnewco1
	common/var/xoldco2,xnewco2
	common/var/xoldvo,xnewvo
	common/var/xoldbo,xnewbo

!	6. g(r) and S(q) Constraints
	common/var/grcounter 
	common/var/delr,delrinv
	common/var/rmax,rmaxsq
	common/var/cellmax
	common/var/nptsgr,igrstart,igrend
	common/var/grexpt
	common/var/grold,grnew
	common/var/grfinal
	common/var/nn,nnch
	common/var/grnormlu
	common/var/sqexpt
	common/var/sqold,sqnew
	common/var/sqconst
	common/var/nptssq_expt_trun

!   7. Volume/Porosity Constraint
	common/var/po_lcellx,po_lcelly,po_lcellz
	common/var/po_cell
	common/var/po_cellC
	common/var/xindex_old,yindex_old,zindex_old
	common/var/xindex_new,yindex_new,zindex_new
	common/var/vol_old,vol_new,vol_change
	common/var/totalcells

!   8. Potential Energy Constraint	
	common/var/nn_cutoff
	common/var/energy_atom,energy_modified
	common/var/old_energy_total,new_energy_total
	common/var/wf_energy
	common/var/xolden,xnewen
	common/var/selector,ta
	common/var/f
	common/var/z,zz
	common/var/avg_ncord,avg_newcord
	common/var/g,g2,g3
	common/var/C_beta,C_sigma,C_a1,C_a2,C_lambda1,C_lambda2
	common/var/C_low_p,C_high_p,C_aa,C_bb,C_xmu,C_xlam
	common/var/C_low,C_high,C_tau1,C_tau2,C_gamma
	common/var/C_qq,C_alpha,c0,zrep2,zdih	
	common/var/S_u1,S_u2,S_u3,S_u4,S_a1,S_a2,S_lambda,S_q0
	common/var/S_alpha,S_B,S_C,S_gamma,S_mu,S_p,S_sigma,S_n,S_beta
	common/var/W_eta,W_A,W_B,W_sigma,W_p,W_alpha,W_lambda,W_gamma
	
!	9.  Coordination Constraint
	common/var/coord_old,coord_new
	common/var/coord_avgold,coord_avgnew
	common/var/coord_avgexp
	
	
!	10. Bond Angle Distribution Constraint	
	common/var/bangold,bangnew
	common/var/bangexp,bangfinal
	common/var/nangold,nangnew
	common/var/nn_bang1
	common/var/nn_bang1_list
	common/var/bocounter
	
	
	
	
!	1. Global Parameter Definitions
!	===============================	
	integer max_atoms
	parameter (max_atoms = 35000)

	integer maximum_nn
	parameter (maximum_nn = 200)

	integer max_sq_data_points
	parameter (max_sq_data_points = 1000)

	integer max_gr_points
	parameter (max_gr_points = 5000)

	integer max_res
	parameter (max_res = 100)
	
	real con_pi
	parameter (con_pi = 3.141592653589793)

!	Boltzmann constant (eV/K)	
	real con_bolt
	parameter (con_bolt = 0.000086173324)
	



	
	
!	2. Input File Variables
!	=======================
!	scrwrite	    - write out simulation detail to screen
!	istart          - start config:1-initial.xyz,2-random, 3-restart
!	config_comp     - number of components (1,2 or 3 only)
!	configA,...     - elemental name of element type A, B and C
!	n_configA,...   - no. of atoms of element A, B and C
!	bond_length1,.. - 6 bond length cutoff distances defining 
!				      neighbors between atom types A,B,C 
!	rho	            - reduced density
!	xl,yl,zl        - cell lengths
!	pbc_option	    - periodic boundary type option 
!   fix_var         - z-axis distance below which atoms are fixed 
!	npre            - number of main steps
!	irun		    - number of data steps
!	ierror	        - number of steps b/w writing data to file
!	iconfig	        - number of steps b/w writing out to xyz file
!	nqpts		    - number of points in fft nqpts = 2^n + 1
!	hdcore          - hard sphere diameter of minimum approach
!	iseed           - seed for random number generator (negative integer)
!	pore_option	    - porosity grids constraint logical flag
!	po_res	        - number of cells in x,y or z direction, resolution 
!	pot_type        - potential type used in energy constraint
!	gr_option	    - g(r) constraint use option
!	sq_option	    - s(q) constraint use option
!	en_option	    - energy constraint use option
!	co_option	    - coordination constraint use option
!	vo_option	    - volume constraint use option 
!	bo_option       - bond angle distribution constraint use option
!	nobond_option   - no bond changes occur from initial logical flag
!	ring3_option    - 3 member ring elimination constraint on/off 
!	quench_option   - linear/exponential quench flag
!	lengthstage(i)  - fraction of simulation in stages in linear quench
!	tempK(i)        - temperature at the start of each stage
!	grerr(i)        - g(r) weighting (variance) at the start of each stage
!	sqerr(i)        - S(q) weighting at the start of each stage
!	coerr(i,j)      - coord constaint weighting at the start of each stage i
!					  for elements j (A, B, C and total T)
!	voerr(i)        - volume constraint weighting at the start of each stage
!	boerr(i)        - vond angle const. weighting at the start of each stage
!	quenchR	        - exp quench rate  T = tempS*quenchR^steps
!	nptsgr_expt     - number of points in experimental g(r)
!	nptssq_expt	    - number of points in experimental S(q)
!	nqstart         - first point fitted in exp S(q)
!	nqfinish        - last point fitted in exp S(q)
!	delq            - spacing for experimental S(q)
!	volume	        - input cell occupancy fraction 
!	coord_exp(i,j)  - same as coord_old, read in experimental from input file
!	co_opt(i)	    - flag for fitting nothing, avg coord or coord histogram
	
	integer scrwrite
	integer istart
	integer config_comp
	character*2 configA, configB, configC
	integer n_configA, n_configB, n_configC
	real bond_length1, bond_length2, bond_length3
	real bond_length12, bond_length13, bond_length23
	real rho
	real xl, yl, zl
	integer pbc_option
	real fix_var
	integer npre
	integer irun
	integer ierror
	integer iconfig
	integer nqpts
	real hdcore
	integer iseed
	logical pore_option
	integer po_res
	integer pot_type
	integer en_option
	integer gr_option, sq_option
	integer co_option, vo_option, bo_option
	integer ring3_option
	logical nobond_option
	integer quench_option
	real lengthstage(3)
	real tempK(4)
	real grerr(4)
	real sqerr(4)
	real coerr(4,4)
	real voerr(4)
	real boerr(4)
	real steper(4)
	real ring3er(4)
	real quenchR
	integer nptsgr_expt, nptssq_expt, nqstart, nqfinish
	real delq
	real volume
	real coord_exp(4,17)
	integer co_opt(4)
	

	
!	3. Simulation parameters
!	========================
!	nmol            - total number of atoms
!	countA,countB,..- No of atoms of type A,B and C after removals etc.
!	step_restart    - step number from restart file to restart sim
!	nmcstep         - current simulation step number
!	xl2,yl2,zl2     - half cell lengths  (0.5*xl)
!	xl2inv,...	    - reciprical half cell lengths (1/(0.5*xl))
!
!   Length of 4 stages of simulation using linear quench (fractional)	
!	|------------------------stage_length4_t------------------------|
!	|-----------------stage_length3_t---------------|
!   |--------stage_length2_t--------|
!   |stage_length1_t| 
!   |         length_stage    length_stage1   length_stage2 (INPUT)
!   |_______________|_______________|_______________|_______________|
!   tempk(1)     tempk(2)       tempK(3)         tempK(4)	
!	
!	tempK_drop(i)   - temperature change per step for 4 stages  
!	step_drop(i)    - stepsize change per step for 4 stages
!	grerr_drop(i)   - g(r) variance change per step for 4 stages
!	sqerr_drop(i)   - S(q) variance change per step for 4 stages  
!	coerr_drop(i,j) - coord constraint variance change per step for 4 stages 
!					  for elements A, B, C, and total (4 constraints) 
!	voerr_drop(i)   - volume constraint variance change per step for 4 stages 
!	boerr_drop(i)   - bond angle const. variance change per step for 4 stages 
!   ring3_drop(i)   - 3 member ring constraint acpt probability change per ...
!	temper	        - current simulation temperature
!	ring3prob       - current 3 member ring constraint acceptance probability
!	quenchR	        - exponential quench rate for T,grerror and sqerror
!			       	  of the form A = A * quenchR^step (INPUT)
!	tempS		    - starting temperature for exp quench (INPUT)
!	grerrS	        - starting gr error weighting for exp quench (INPUT)
!	sqerrS	        - starting sq error weighting for exp quench (INPUT)
!	stepsize	    - current simulation stepsize 
!	mvsacpt	        - number of accepted translational moves
!	mvsacpt         - number of accepted switching moves
!	stage_no        - simulation stage via linear quench (4 stages)
!	nstage	        - quench stage (nstage=1), equilibriated stage (=2)
!	ichosen	        - randomly chosen atom for attempted MC move
!	move_rejected   - flag for rejecting an attempted MC move
!	hdcoresq        - hdcore*hdcore 
!	move_type       - type of move being attempted 
!	newnn           - ichosen post move 1st nn coordination
!	newlist(i)      - ichosen post move nn list
!	c_lab(i)	    - elemental label for multi-component systems
!	select_a,...    - the two selected atom for switching move attempt
!	select_aold,... - labels of the two selected atoms before switching 
!   fix_atom(i)     - array of atoms that can not move

	integer nmol, countA, countB, countC
	integer step_restart, nmcstep
	real xl2, yl2, zl2
	real xl2inv, yl2inv, zl2inv
	real  stage_length1_t, stage_length2_t
	real  stage_length3_t, stage_length4_t
	double precision tempK_drop(4)
	double precision step_drop(4)
	double precision grerr_drop(4)
	double precision sqerr_drop(4)
	double precision coerr_drop(4,4)
	double precision voerr_drop(4)
	double precision boerr_drop(4)
	double precision ring3_drop(4)
	double precision temper 
	double precision ring3prob
	double precision stepsize	
	integer mvsacpt, mvsacpt2
	integer stage_no, nstage
	integer ichosen
	logical move_rejected
	real hdcoresq
	integer move_type
	integer newnn  
	integer newlist(500) 
	integer c_lab(max_atoms)
	integer select_a, select_b
	integer select_aold, select_bold
	integer fix_atom(max_atoms)
	
	
!	4. Neighbor Lists
!	=================
!	dr(i,j)         - distance between atom i and neighbor j
!	dxdr(i,j)       - x components of distance between i and j
!	dydr(i,j)       - y components of distance between i and j
!	dzdr(i,j)       - z components of distance between i and j
!	xc(i),yc(i),... - x,y,z coordinate of atoms
!	xnewi,ynewi,... - new position of moved atom

!	ncord(i)        - pot cutoff coord of atom i pre-move
!	num(i)	        - pot cutoff coord of atom i post-move
!	ncord_b(i)	    - dist cutoff coord of atom i pre-move
!	num_b(i)	    - dist cutoff coord of atom i post-move

!	nnlist(i,j)     - pot cutoff neighbors j of atom i pre-move
!	near(i,j)       - pot cutoff neighbors j of atom i post-move
!	nnlist_b(i,j)   - dist cutoff neighbors j of atom i pre-move
!	near_b(i,j)     - dist cutoff neighbors j of atom i post-move
!
!	en_ch_sum	    - number of nn out to 2nd nn pre and post move
!	en_ha_sum	    - number of nn out to 3nd nn pre and post move
!	en_to_sum	    - number of nn out to 4nd nn pre and post move
!	en_ch_list      - ichosen's nn out to 2nd nn pre and post move
!	en_ha_list	    - ichosen's nn out to 3rd nn pre and post move
!	en_to_list	    - ichosen's nn out to 4th nn pre and post move
!
	
	real dr(max_atoms,maximum_nn)
	real dxdr(max_atoms,maximum_nn)
	real dydr(max_atoms,maximum_nn)
	real dzdr(max_atoms,maximum_nn)
	real xc(max_atoms),yc(max_atoms),zc(max_atoms)
	real xnewi,ynewi,znewi
	
	integer ncord(max_atoms)
	integer num(max_atoms)
	integer ncord_b(max_atoms)
	integer num_b(max_atoms) 
	
	integer nnlist(max_atoms,maximum_nn)
	integer near(max_atoms,maximum_nn) 
	integer nnlist_b(max_atoms,maximum_nn)
	integer near_b(max_atoms,maximum_nn)
	
	integer en_ch_sum, en_ha_sum, en_to_sum
	integer en_ch_list(50000), en_ha_list(50000), en_to_list(50000)
	
	
	
!	5. Cost Functions
!	=================	
!	gr_error        - g(r) constraint variance weighting 
!	sq_error        - S(q) constraint variance weighting
!	co_error        - coordination constraint variance weighting
!	vo_error        - volume constraint variance weighting
!	bo_error        - bond angle dist. constraint variance weighting
!	xoldtt, xnewtt  - pre-move and post-move total error
!	xoldgr, xnewgr  - pre_move and post-move g(r) error
!	xoldsq, xnewsq  - pre-move and post-move S(q) error
!	xoldco1,xnewco2 - average coord constraint error pre and post move
!				      elements are type A, B, C and total
!	xoldco2,xnewco2 - coord histogram constraint error pre and post move
!	xoldvo	        - pre-move volume constraint error
!	xnewvo	        - post-move volume constraint error
!	xoldbo,xnewbo   - bond ang dist constraint error pre and post move
 
	double precision gr_error, sq_error
	double precision co_error(4), vo_error, bo_error
	real xoldtt, xnewtt
	real xoldgr, xnewgr
	real xoldsq, xnewsq
	real xoldco1(4), xnewco1(4)
	real xoldco2(4), xnewco2(4)	 
	real xoldvo, xnewvo
    real xoldbo, xnewbo
     


!	6. g(r) and S(q) Constraints
!	============================
!	grcounter	    - number of averages of the summed g(r) in data stage
!	delr,delrinv    - g(r) spacing based on delq, 1/delr
!	rmax,rmaxsq	    - maximum g(r) range, rmax*rmax
!	cellmax	        - smallest cell length side used to work out the
!				      number of points in the g(r).
!	nptsgr          - number of points in fitted g(r) 
!	igrstart,igrend - gr start and end point used for looping 
!	grexpt(i)       - experimental g(r) read in from grexp.dat file
!	grold(i)        - g(r) pre-move
!	grnew(i) 	    - g(r) post-move
!	grfinal(i)      - g(r) averaged over final stage (output to grfinal.dat)
!	nn(i)	        - g(r) histogram before normalization
!	nnch(i)         - g(r) histogram change post-move before normalization
!	grnormlu(i)     - g(r) normalization function for nn(i) histogram 
!	sqexpt(i)       - experimental S(q) with nqstart and nqfinish range
!	sqold(i)	    - S(q) pre-move
!	sqnew(i)	    - S(q) post-move
!	sqconst         - Constant for S(q) normalization
!	nptssq_expt_trun- q point in exp S(q) with nqstart & nqfinish range
	
	integer grcounter
	real delr,delrinv
	real rmax,rmaxsq
	real cellmax
	integer nptsgr, igrstart,igrend
	real grexpt(max_gr_points)
	real grold(max_gr_points), grnew(max_gr_points) 	
	real grfinal(max_gr_points)
	integer nn(max_gr_points), nnch(max_gr_points)
	real grnormlu(max_gr_points)
	
	real sqexpt(max_sq_data_points)
	real sqold(max_sq_data_points),sqnew(max_sq_data_points)	
	real sqconst
	integer nptssq_expt_trun
	
	

	

!   7. Volume/Porosity Constraint
!   =============================
!	po_lcellx,...   - grid cell size in x,y,z direction 
!	po_cell	        - porosity grid array storing atomic occupancy
!                     0 = pore/empty, N = containing N atoms
!	po_cellC	    - read in porosity grid array forbidding MC moves 
!                     1 = empty pore grid, 0 = bulk space for MC moves
!	xindex_old,...  - pore cell x index of pre-move atom location
!	xindex_new,...  - pore cell x index of post-move atom location

!	vol_old	        - number of pre-move occupied cells
!	vol_new	        - number of post-move occupied cells
!	vol_change	    - change in occupied cells resulting from move
!	totalcells	    - total number of cells in simulation


	real po_lcellx, po_lcelly, po_lcellz
	integer po_cell(max_res,max_res,max_res)
	integer po_cellC(max_res,max_res,max_res)      
	integer xindex_old, yindex_old, zindex_old
	integer xindex_new, yindex_new, zindex_new	
	
	real vol_old,vol_new,vol_change
	real totalcells
	
	
	
!   8. Potential Energy Constraint
!   ==============================
!	nn_cutoff	    - cutoff distance for potentials and nn affect lists
!	energy_atom(i)  - energy of atom i, pre_move
!	energy_modified - new energy of atoms affected post_move
!	old_energy_total- total energy pre_move
!	new_energy_total- total energy post_move
!	wf_energy	    - weighting factor for energy constraint
!	xolden,xnewen   - energy constraint errors pre and post move
!	selector, ta    - carbon edip atom label that is being calculated
!
!	f(i,j)          - EDIP carbon cutoff function
!	z(i)   	        - EDIP fractional coordination pre_move
!	zz(i)		    - EDIP fractional coordination post_move
!	avg_ncord(i)    - EDIP fractional coordination pre_move
!	avg_newcord(i)  - EDIP fractional coordination post_move
!	g(i),g2(i),g3...- EDIP carbon Pi functions 

	real nn_cutoff
	real energy_atom(max_atoms), energy_modified(max_atoms)
	real old_energy_total, new_energy_total
	double precision wf_energy
	real xolden, xnewen
	integer selector, ta 

	real f(max_atoms,600) 
	real z(max_atoms), zz(max_atoms) 
	real avg_ncord(max_atoms), avg_newcord(max_atoms)
	real g(max_atoms), g2(max_atoms), g3(max_atoms)

!	Carbon EDIP parameters
	real C_beta, C_sigma, C_a1, C_a2, C_lambda1, C_lambda2	
	real C_low_p, C_high_p, C_aa, C_bb, C_xmu, C_xlam
	real C_low, C_high, C_tau1, C_tau2, C_gamma	
	real C_qq, C_alpha, c0, zrep2, zdih
	
!	Silicon EDIP parameters	
	real S_u1, S_u2, S_u3, S_u4, S_a1, S_a2, S_lambda, S_q0
	real S_alpha, S_B, S_C, S_gamma, S_mu, S_p, S_sigma, S_n, S_beta

!	Stillinger-Web parameters
	real W_eta, W_A, W_B, W_sigma, W_p, W_alpha, W_lambda, W_gamma
	
	
!	9.  Coordination Constraint
!	===========================
!	coord_old(i,j)  - fraction of atom of type i with a coordination
!	                  of j.  i is atom type A, B, C and total
!	                  j=1 is the coordination 0 place, j=17 is cord=16
!	coord_new(i,j)  - same as coord_old but for post move position
!	coord_avgold(i) - avg coordination of atom type A, B, C and total premove
!	coord_avgnew(i) - same as coord_avgold(i) post-move.
!	coord_avgexp(i) - same as coord_avgold(i), read in experimental from input


	integer coord_old(4,17),coord_new(4,17)
	real coord_avgold(4), coord_avgnew(4)
	real coord_avgexp(4)
	
	
	
!	10. Bond Angle Distribution Constraint
!	======================================
!	bangold(i),...  - un-normalized bond angle distribution pre and post move
!	bangexp(i)      - normalized experimental bond angle dist from file
!	bangfinal(i)    - normalized average bond angle dist in data stage
!	nangold,nangnew - total number of bond angles pre and post move
!	nn_bang1        - number of 1st nn + ichosen in pre and post positions
!	nn_bang1_list(i)- list of 1st nn + ichosen in pre and post positions
!   bocounter       - data stage counter for averaging final bond angle dist

	integer bangold(180), bangnew(180)
	real bangexp(180),bangfinal(180)
	integer nangold, nangnew
	integer nn_bang1
	integer nn_bang1_list(1000) 
	integer bocounter
  
	

	